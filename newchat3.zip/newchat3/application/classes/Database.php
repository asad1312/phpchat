<?php
	defined('INSITE') or die("No direct script access allowed");
	class Database{
		public $db;
		public function __construct(){
			$options = [
				PDO::ATTR_EMULATE_PREPARES => false,
				PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
				PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
			];
			$now = new DateTime();
            $mins = $now->getOffset() / 60;
            $sgn = ($mins < 0 ? -1 : 1);
            $mins = abs($mins);
            $hrs = floor($mins / 60);
            $mins -= $hrs * 60;
            $offset = sprintf('%+d:%02d', $hrs*$sgn, $mins);
			try{
				switch(SQL_PDO){
					case 'mysqli':
						$this->db = new PDO("mysql:host=".SQL_HOST.";dbname=".SQL_WEB_DB, SQL_USER, SQL_PASSWORD, $options);
						$this->db->exec("SET NAMES utf8mb4;");
						$this->db->exec("SET time_zone='$offset';");
						break;
					default:
						die('Incorrect PDO driver!');
				}
			}
			catch(PDOException $e){
				die(print_r($e->getMessage()));
			}
		}
	}
