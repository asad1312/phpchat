<?php
defined('INSITE') or die('No direct script access allowed');
class Admin extends Database {
    public function getLatestUsers() {
        $sth = $this->db->query("SELECT * FROM ".SQL_WEB_DB.".`users` ORDER BY `createDate` DESC LIMIT 5");
        if($sth->rowCount()) {
            return ($sth->fetchAll());
        }
        return null;
    }
    public function CreateRoom($data = []) {
        if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
		$required_fields = ['title', 'icon'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
        $sth = $this->db->prepare("INSERT INTO ".SQL_WEB_DB.".`channels` (`title`, `icon`) VALUES (:title, :icon)");
        $sth->execute([':title' => $data['title'], ':icon' => $data['icon']]);
        return ['success' => 'חדר נפתח בהצלחה! אנא המתן!'];
    }
    public function DeleteRoom($data = []) {
        if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
		$required_fields = ['room'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
        $Chat = new Chat;
        $channel_info = $Chat->getChannel($data['room']);
        if(!is_array($channel_info)) {
            return ['error' => 'חדר לא תקין!'];
        }
        $sth = $this->db->prepare("DELETE FROM ".SQL_WEB_DB.".`channels` WHERE `id` = :id");
        $sth->execute([':id' => $data['room']]);
        return ['success' => 'חדר נמחק בהצלחה!'];
    }
}
