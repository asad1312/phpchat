<?php
defined('INSITE') or die('No direct script access allowed');
class Account extends Database {
	/*
		userType INT DEFAULT 1,
		1 => normal user
		2 => guest
	*/
    public function IsLogged() {
        return isset($_SESSION['is_loginedIn']);
    }
	public function IsGuest() {
		return isset($_SESSION['guest']);
	}
    public function IsAdmin() {
        return isset($_SESSION['admin']);
    }
    public function Login($data = []) {
		if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
        $required_fields = ['username', 'password'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
    	$Website = new Website;
		if (strlen($data['username']) < 4 || strlen($data['username']) > 36 ) {
			return ['error' => 'שם המשתמש יכול להכיל אותיות ומספרים בלבד! אורך בין 4 ל36!'];
        }
        if (strlen($data['password']) < 4 || strlen($data['password']) > 36 || !ctype_alnum($data['password'])) {
            return ['error' => 'סיסמה יכולה להכיל אותיות ומספרים בלבד! אורך בין 4 ל36!'];
        }
		if($Website->check_login_attemts()) {
            return ['error' => 'הגעת למקסימום ניסיונות התחברות! נסה שנית בעוד כ-15 דקות!'];
        }
		$sth = $this->db->prepare("SELECT `password` FROM ".SQL_WEB_DB.".`users` WHERE `username` = :username LIMIT 1");
		$sth->execute([':username' => $data['username']]);
		if($sth->rowCount()){
			$row = $sth->fetch();
			if(verify_password($data['password'], $row['password'])) {
				$Website->clear_login_attemts();
				$_SESSION['username'] = $data['username'];
				$_SESSION['is_loginedIn'] = true;
				$_SESSION['room'] = (new Chat)->getDefaultRoom();

				if(in_array($data['username'], explode(',', ADMIN_LIST))) {
					$_SESSION['admin'] = 1;
				}
				$this->UpdateActivity($data['username']);
				$this->UpdateIp($data['username']);
				return ['success' => 'התחברת בהצלחה! אנא המתן...'];
			}
			$Website->add_login_attemt();
			return ['error' => 'שם משתמש או סיסמה לא תקינים!'];
		}
		$Website->add_login_attemt();
		return ['error' => 'שם משתמש או סיסמה לא תקינים!'];
    }
    public function LogOut() {
        session_destroy();
    }
    public function UserInfo($user_email, $email = false) {
		$column = ($email == false) ? 'username' : 'email';
        $sth = $this->db->prepare("SELECT * FROM ".SQL_WEB_DB.".`users` WHERE ".$column." = :user_email LIMIT 1");
        $sth->execute([':user_email' => $user_email]);
        if ($sth->rowCount()) {
            $row = $sth->fetch();
			$row['profileInfo'] = (json_decode($row['profileInfo'], true))['profile'];
			$row['otherInfo'] = (json_decode($row['otherInfo'], true))['other'];
            return $row;
        }
        return null;
    }
	public function UserInfoId($user_id) {
		$column = '`id`';
        $sth = $this->db->prepare("SELECT * FROM ".SQL_WEB_DB.".`users` WHERE ".$column." = :user_id LIMIT 1");
        $sth->execute([':user_id' => $user_id]);
        if ($sth->rowCount()) {
            $row = $sth->fetch();
			$row['profileInfo'] = (json_decode($row['profileInfo'], true))['profile'];
			$row['otherInfo'] = (json_decode($row['otherInfo'], true))['other'];
            return $row;
        }
        return null;
    }
	public function UpdateActivity($username) {
		$sth = $this->db->prepare("UPDATE ".SQL_WEB_DB.".users SET `lastActivity` = ".(int)time()." WHERE `username` = :username");
        $sth->execute([':username' => $username]);
	}
    private function UpdatePassword($username, $password_new) {
        $sth = $this->db->prepare("UPDATE ".SQL_WEB_DB.".users SET `password` = :password WHERE `username` = :username");
        $sth->execute([':password' => password_encrypt($password_new), ':username' => $username]);
    }
	private function UpdateEmail($username, $email_new) {
        $sth = $this->db->prepare("UPDATE ".SQL_WEB_DB.".users SET `email` = :email WHERE `username` = :username");
        $sth->execute([':email' => $email_new, ':username' => $username]);
    }
	private function UpdateProfile($username, $profile_json) {
		$sth = $this->db->prepare("UPDATE ".SQL_WEB_DB.".users SET `profileInfo` = :profileInfo WHERE `username` = :username");
        $sth->execute([':profileInfo' => $profile_json, ':username' => $username]);
	}
	private function UpdateOther($username, $other_json) {
		$sth = $this->db->prepare("UPDATE ".SQL_WEB_DB.".users SET `otherInfo` = :otherInfo WHERE `username` = :username");
        $sth->execute([':otherInfo' => $other_json, ':username' => $username]);
	}
	private function UpdateIp($username) {
		$sth = $this->db->prepare("UPDATE ".SQL_WEB_DB.".users SET `lastIp` = :ip WHERE `username` = :username");
        $sth->execute([':ip' => getUserIpAddr(), ':username' => $username]);
	}
	public function ChangeEmail($data = []) {
		if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
		$required_fields = ['currentEmail', 'newEmail'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
		if (!filter_var($data['currentEmail'], FILTER_VALIDATE_EMAIL)) {
            return ['error' => 'מייל לא תקין!'];
        }
		if (!filter_var($data['newEmail'], FILTER_VALIDATE_EMAIL)) {
            return ['error' => 'מייל לא תקין!'];
        }
		$user_info = $this->UserInfo($_SESSION['username']);
		if($data['currentEmail'] != $user_info['email']) {
			return ['error' => 'אימייל נוכחי לא תקין!'];
		}
		if (is_array($this->UserInfo($data['newEmail'], true))) {
            return ['error' => 'מייל זה נמצא כבר בשימוש!'];
        }
		$this->UpdateEmail($_SESSION['username'], $data['newEmail']);
		$this->UpdateActivity($_SESSION['username']);
		return ['success' => 'מייל עודכן בהצלחה!', 'new_email' => encrypt_email($data['newEmail'])];
	}
	public function ChangePassword($data = []) {
		if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
		$required_fields = ['currentPassword', 'newPassword', 'confirmPassword'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
		if (strlen($data['currentPassword']) < 4 || strlen($data['currentPassword']) > 36 || !ctype_alnum($data['currentPassword'])) {
            return ['error' => 'סיסמה יכולה להכיל אותיות ומספרים בלבד! אורך בין 4 ל36!'];
        }
		if (strlen($data['newPassword']) < 4 || strlen($data['newPassword']) > 36 || !ctype_alnum($data['newPassword'])) {
            return ['error' => 'סיסמה יכולה להכיל אותיות ומספרים בלבד! אורך בין 4 ל36!'];
        }
		if (strlen($data['confirmPassword']) < 4 || strlen($data['confirmPassword']) > 36 || !ctype_alnum($data['confirmPassword'])) {
            return ['error' => 'סיסמה יכולה להכיל אותיות ומספרים בלבד! אורך בין 4 ל36!'];
        }
        if ($data['newPassword'] != $data['confirmPassword']) {
			return ['error' => 'סיסמאות לא תואמות!'];
        }
		$user_info = $this->UserInfo($_SESSION['username']);
		if(!verify_password($data['currentPassword'], $user_info['password'])) {
			return ['error' => 'סיסמה נוכחית לא תואמת לחשבון!'];
		}
		$this->UpdatePassword($_SESSION['username'], $data['newPassword']);
		$this->UpdateActivity($_SESSION['username']);
		return ['success' => 'סיסמה עודכנה בהצלחה!'];
	}
	public function ChangeAbout($data = []) {
		if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
		$required_fields = ['aboutMe'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
		$user_info = $this->UserInfo($_SESSION['username']);
		$otherInfo = [];
		$otherInfo['other'] = $user_info['otherInfo'];
		$otherInfo['other']['about'] = $data['aboutMe'];
		$this->UpdateOther($_SESSION['username'], json_encode($otherInfo));
		$this->UpdateActivity($_SESSION['username']);
		return ['success' => 'אודות עודכן בהצלחה!'];
	}
	public function ChangeArea($data = []) {
		if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
		$required_fields = ['area'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
		$user_info = $this->UserInfo($_SESSION['username']);
		$profile_info = [];
		$profileInfo['profile'] = $user_info['profileInfo'];
		$profileInfo['profile']['area'] = $data['area'];
		$this->UpdateProfile($_SESSION['username'], json_encode($profileInfo));
		$this->UpdateActivity($_SESSION['username']);
		return ['success' => 'אזור עודכן בהצלחה!', 'area' => $data['area']];
	}
	public function ChangeAge($data = []) {
		if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
		$required_fields = ['age'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
		$user_info = $this->UserInfo($_SESSION['username']);
		$profile_info = [];
		$profileInfo['profile'] = $user_info['profileInfo'];
		$profileInfo['profile']['age'] = $data['age'];
		$this->UpdateProfile($_SESSION['username'], json_encode($profileInfo));
		return ['success' => 'גיל עודכן בהצלחה!', 'age' => $data['age']];
	}
	public function ChangeGender($data = []) {
		if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
		$required_fields = ['gender'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
		$user_info = $this->UserInfo($_SESSION['username']);
		$profile_info = [];
		$profileInfo['profile'] = $user_info['profileInfo'];
		$profileInfo['profile']['gender'] = $data['gender'];
		$this->UpdateProfile($_SESSION['username'], json_encode($profileInfo));
		$this->UpdateActivity($_SESSION['username']);
		return ['success' => 'מין עודכן בהצלחה!', 'gender' => $data['gender']];
	}
	public function GetProfile($data = []) {
		if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
		$required_fields = ['user_id'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
		/*if(is_numeric($data['user_id'])) {
			$user_info = $this->UserInfoId($data['user_id']);
		} else {*/
			$user_info = $this->UserInfo($data['user_id']);
		//}
		if(!is_array($user_info)) {
			return ['error' => $data['user_id'].'משתמש לא נמצא!'];
		}
		unset($user_info['password'], $user_info['lastIp'], $user_info['userType'], $user_info['email']);
		$genders = genders();
		$areas = areas();
		$user_info['profileInfo']['gender'] = (array_key_exists($user_info['profileInfo']['gender'], $genders) ? $genders[$user_info['profileInfo']['gender']]['title'] : 'לא ידוע ('.$user_info['profileInfo']['gender'].')');
		$user_info['profileInfo']['area'] = (array_key_exists($user_info['profileInfo']['area'], $areas) ? $areas[$user_info['profileInfo']['area']]['title'] : 'לא ידוע ('.$user_info['profileInfo']['area'].')');
		return $user_info;
	}
	public function RecoveryPassword($data = []){
		if(!is_array($data) || !count($data)){
			return ['error' => ['System error!']];
		}
		$error = [];
		switch($data['step']){
			case 1:
				$required_fields = ['email', 'website_url'];
				if(!CheckFields($required_fields, $data)) {
					$error[] = 'Complete all required fields!';
				}
				if(!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
					$error[] = 'Wrong e-mail format!';
				}
				if(!count($error)) {
					$user_info = $this->UserInfo($data['email'], true);
					if(is_array($user_info)) {
						if(USE_SMTP == 1) {
							$token = bin2hex(openssl_random_pseudo_bytes(16));
							$link = $data['website_url'].'/lost_password/'.$token;
							$img = $data['website_url'].'/assets/default_assets/img/logo.png';
							$message = file_get_contents('application/email_templates/account_password_recovery.txt');
							$message = str_replace(['{nickname}', '{logo}', '{activation_link}', '{help}'], [$user_info['name'], $img, $link],$message);
							if(SendEmail($data['email'], 'Password Recovery' ,$message)) {
								$sth = $this->db->prepare("UPDATE ".SQL_GAME_DB.".users SET recovery_token = :token, recovery_time = NOW() WHERE email = :email");
								$sth->execute([':token' => $token, ':email' => $data['email']]);
								$success = 'Link with password recovery sent to '.$data['email'].'!';
							}
							else {
								$error[] = 'Failed to send email!';
							}
						} else {
							$error[] = 'Password recovery disabled!';
						}
					} else {
						$error[] = 'Email not exists!';
					}
				}
				break;
			case 2:
				if(!isset($data['token'])) {
					return ['error' => ['System error!']];
				}
				$sth = $sth = $this->db->prepare("SELECT * FROM ".SQL_GAME_DB.".users WHERE recovery_token = :token LIMIT 1");
				$sth->execute([':token' => $data['token']]);
				if(!$sth->rowCount()) {
					$error[] = 'Password recovery token not valid!';
				}
				$token_info = $sth->fetch();
				$expire_time = strtotime($token_info['recovery_time']);
				$expire_time += (3600 * 24);
				if(($expire_time) < time()) {
					$error[] = 'Password recovery token expired!';
				}
				if(!count($error)) {
					$_SESSION['recovery_acc'] = $token_info['name'];
				}
				break;
			case 3:
				if(!isset($_SESSION['recovery_acc'])) {
					return ['error' => ['System error!']];
				}
				$required_fields = ['new_password', 'new_password_confirm'];
				if(!CheckFields($required_fields, $data)) {
					$error[] = 'Complete all required fields!';
				}
				if(strlen($data['new_password']) < 4 || strlen($data['new_password']) > 16 || !ctype_alnum($data['new_password'])) {
					$error[] = 'Password must contain numbers/characters only! Lenght must be between 4 and 16 characters!';
				}
				if($data['new_password'] != $data['new_password_confirm']) {
					$error[] = 'Passwords did not match!';
				}
				if(!count($error)) {
					$this->UpdatePassword($_SESSION['recovery_acc'], $data['new_password']);
					$sth = $sth = $this->db->prepare("UPDATE ".SQL_GAME_DB.".users SET recovery_token = NULL WHERE name = :username");
					$sth->execute([':username' => $_SESSION['recovery_acc']]);
					unset($_SESSION['recovery_acc']);
					$success = 'Password successfully changed!';
				}
				break;
		}
		if(count($error)) {
			return ['error' => $error];
		}
		if(isset($success)) {
			return ['success' => $success];
		}
	}
	public function RegisterGuest($data = []) {
	    if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
        $required_fields = ['username', 'age', 'gender', 'area', 'rules'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
        if (strlen($data['username']) < 4 || strlen($data['username']) > 36 ) {
			return ['error' => 'שם המשתמש יכול להכיל אותיות ומספרים בלבד! אורך בין 4 ל36!'];
        }
        if($data['rules'] !== 'yes') {
        	return ['error' => 'עליך להסכים לתנאי השימוש!'];
        }
        if (is_array($this->UserInfo($data['username']))) {
            return ['error' => 'שם משתמש זה נמצא כבר בשימוש!'];
        }
        $data['password'] = 'guest-'.base64_encode(time());
        $data['email'] = $data['password'].'@guest.com';
		$data['ip'] = getUserIpAddr();
		$data['password'] = password_encrypt($data['password']);
		$other = [
			'other' => [
				'about' => 'אנא עדכן שורה זו דרך הגדרות המשתמש'
			]
		];
		$profileInfo = [
			'profile' => [
				'age' => $data['age'],
				'gender' => $data['gender'],
				'area' => $data['area']
			]
		];
		$data['profileInfo'] = json_encode($profileInfo);
		$data['otherInfo'] = json_encode($other);
		$sth = $this->db->prepare("INSERT INTO ".SQL_WEB_DB.".`users` (`username`, `password`, `email`, `profileInfo`, `otherInfo`, `lastIp`, `guest`) VALUES (:username, :password, :email, :profileInfo, :otherInfo, :ip, 1)");
		$sth->bindParam(':username', $data['username'], PDO::PARAM_STR);
		$sth->bindParam(':password', $data['password'], PDO::PARAM_STR);
		$sth->bindParam(':email', $data['email'], PDO::PARAM_STR);
		$sth->bindParam(':profileInfo', $data['profileInfo'], PDO::PARAM_STR);
		$sth->bindParam(':otherInfo', $data['otherInfo'], PDO::PARAM_STR);
		$sth->bindParam(':ip', $data['ip'], PDO::PARAM_STR);
		try {
			if($sth->execute()) {
			    $_SESSION['username'] = $data['username'];
				$_SESSION['room'] = (new Chat)->getDefaultRoom();
				$_SESSION['is_loginedIn'] = true;
				$_SESSION['user_id'] = $this->db->lastInsertId();
				if(in_array($data['username'], explode(',', ADMIN_LIST))) {
					$_SESSION['admin'] = 1;
				}
				$this->UpdateActivity($data['username']);
				$this->UpdateIp($data['username']);
				return ['success' => 'חשבון נוצר בהצלחה! אנא המתן...'];
			}
		} catch (Exception $e) {
			return ['error' => 'אממ...נראה שיש בעיה מהצד שלנו. צור קשר עם אדמין!'];
		}
	}




	public function updateGuestUserName($data = []) {


		$sth = $this->db->prepare("UPDATE ".SQL_WEB_DB.".users SET `username` = :username  WHERE `id` = :id");
        $sth->execute([':id' => $data['user_id'],':username' =>$data['username']]);
        $_SESSION['username'] = $data['username'];

	}

    public function Register($data = []) {
        if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
        $required_fields = ['username', 'email', 'password', 'confirm_password', 'age', 'gender', 'area', 'rules'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
        if (strlen($data['username']) < 4 || strlen($data['username']) > 36 ) {
			return ['error' => 'שם המשתמש יכול להכיל אותיות ומספרים בלבד! אורך בין 4 ל36!'];
        }
        if (strlen($data['password']) < 4 || strlen($data['password']) > 36 || !ctype_alnum($data['password'])) {
            return ['error' => 'סיסמה יכולה להכיל אותיות ומספרים בלבד! אורך בין 4 ל36!'];
        }
        if ($data['password'] != $data['confirm_password']) {
			return ['error' => 'סיסמאות לא תואמות!'];
        }
        if($data['rules'] !== 'yes') {
        	return ['error' => 'עליך להסכים לתנאי השימוש!'];
        }
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            return ['error' => 'מייל לא תקין!'];
        }
        if (is_array($this->UserInfo($data['username']))) {
            return ['error' => 'שם משתמש זה נמצא כבר בשימוש!'];
        }
		if (is_array($this->UserInfo($data['email'], true))) {
            return ['error' => 'מייל זה נמצא כבר בשימוש!'];
        }
		$data['ip'] = getUserIpAddr();
		$data['password'] = password_encrypt($data['password']);
		$other = [
			'other' => [
				'about' => 'אנא עדכן שורה זו דרך הגדרות המשתמש'
			]
		];
		$profileInfo = [
			'profile' => [
				'age' => $data['age'],
				'gender' => $data['gender'],
				'area' => $data['area']
			]
		];
		$data['profileInfo'] = json_encode($profileInfo);
		$data['otherInfo'] = json_encode($other);
		$sth = $this->db->prepare("INSERT INTO ".SQL_WEB_DB.".`users` (`username`, `password`, `email`, `profileInfo`, `otherInfo`, `lastIp`) VALUES (:username, :password, :email, :profileInfo, :otherInfo, :ip)");
		$sth->bindParam(':username', $data['username'], PDO::PARAM_STR);
		$sth->bindParam(':password', $data['password'], PDO::PARAM_STR);
		$sth->bindParam(':email', $data['email'], PDO::PARAM_STR);
		$sth->bindParam(':profileInfo', $data['profileInfo'], PDO::PARAM_STR);
		$sth->bindParam(':otherInfo', $data['otherInfo'], PDO::PARAM_STR);
		$sth->bindParam(':ip', $data['ip'], PDO::PARAM_STR);
		try {
			if($sth->execute()) {
			    $_SESSION['username'] = $data['username'];
				$_SESSION['room'] = (new Chat)->getDefaultRoom();
				$_SESSION['is_loginedIn'] = true;
				if(in_array($data['username'], explode(',', ADMIN_LIST))) {
					$_SESSION['admin'] = 1;
				}
				$this->UpdateActivity($data['username']);
				$this->UpdateIp($data['username']);
				return ['success' => 'חשבון נוצר בהצלחה! אנא המתן...'];
			}
		} catch (Exception $e) {
			return ['error' => 'אממ...נראה שיש בעיה מהצד שלנו. צור קשר עם אדמין!'];
		}
    }
}
