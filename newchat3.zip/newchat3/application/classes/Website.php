<?php
	defined('INSITE') or die('No direct script access allowed');
	class Website{
		public $settings = [];
		public function __construct(){
			$this->settings = $this->GetSettings();
		}
		public function AjaxToken() {
		    if (!isset($_SESSION['csrf_token'])) {
                $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(16).uniqid());
                $_SESSION['csrf_token_valid'] = strtotime('now +1 hour');
            } elseif(isset($_SESSION['csrf_token_valid']) && $_SESSION['csrf_token_valid'] < time()) {
                unset($_SESSION['csrf_token'], $_SESSION['csrf_token_valid']);
                $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(16).uniqid());
                $_SESSION['csrf_token_valid'] = strtotime('now +1 hour');
            }
		}
		public function VerifyAjax() {
		    $headers = apache_request_headers();
		    return (isset($headers['Token']) && isset($_SESSION['csrf_token']) && $headers['Token'] == $_SESSION['csrf_token'] && isset($_SESSION['csrf_token_valid']) && $_SESSION['csrf_token_valid'] > time());
		}
		public function SaveSettings($data = []){
			if(!is_array($data) || !count($data)){
				return ['error' => 'System error!'];
			}
			$error = [];
			$required_fields = ['web_url', 'web_title', 'captcha_enable'];
			if(!CheckFields($required_fields, $data)){
				$error[] = 'Complete all required fields!';
			}
			if(!filter_var($data['web_url'], FILTER_VALIDATE_URL)){
				$error[] = 'Website URL not valid!';
			}
			if($data['captcha_enable'] == 1){
				if(empty($data['captcha_site_key']) || empty($data['captcha_secret_key'])){
					$error[] = 'Complete All Captcha Settings!';
				}
			}
			if(count($error)){
				return ['error' => $error];
			}
			$data['web_url'] = rtrim($data['web_url'], '/');
			file_put_contents(BASE_DIR.'application/website_settings.json', json_encode($data));
			return ['success' => 'Website settings updated!'];
		}
		private function GetSettings(){
			$path = BASE_DIR.'application/website_settings.json';
			if(file_exists($path)){
				$web_settings = file_get_contents($path);
				return json_decode($web_settings);
			}
			return null;
		}
		public function CheckCaptcha($secret_key, $captcha_response){
			$g_response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$secret_key."&response=".$captcha_response."&remoteip=".$_SERVER['REMOTE_ADDR']);
			$g_response = json_decode($g_response, true);
			return (!empty($g_response['success'])) ? true : false;
		}
		public function check_login_attemts() {
            $file = BASE_DIR.'application/logs/login_attempts.txt';
            if(file_exists($file)){
                $data = file_get_contents($file);
                if($data != false && $data != ''){
                    $ips = unserialize($data);
                    if(isset($ips[getUserIpAddr()]) && $ips[getUserIpAddr()]['time'] >= time() - 900){
                        return $ips[getUserIpAddr()]['attempts'] >= 5;
                    }
                }
            }
            return false;
        }
        public function add_login_attemt() {
            $file = BASE_DIR.'application/logs/login_attempts.txt';
            if(!file_exists($file)){
                file_put_contents($file, '');
            }
            $data = file_get_contents($file);
            if($data != false && $data != ''){
                $ips = unserialize($data);
                if(isset($ips[getUserIpAddr()])){
                    $ips[getUserIpAddr()]['attempts'] = $ips[getUserIpAddr()]['attempts'] + 1;
                    $ips[getUserIpAddr()]['time'] = time();
                } else{
                    $ips[getUserIpAddr()]['attempts'] = 1;
                    $ips[getUserIpAddr()]['time'] = time();
                }
            } else{
                $ips = [getUserIpAddr() => ['attempts' => 1, 'time' => time()]];
            }
            file_put_contents($file, serialize($ips));
            return true;
        }
        public function clear_login_attemts() {
            $file = BASE_DIR.'application/logs/login_attempts.txt';
            if(file_exists($file)){
                $data = file_get_contents($file);
                if($data != false && $data != ''){
                    $ips = unserialize($data);
                    if(isset($ips[getUserIpAddr()])){
                        unset($ips[getUserIpAddr()]);
                        file_put_contents($file, serialize($ips));
                    }
                }
            }
            return true;
        }
		public function Redirect($url = null){
			if(is_null($url)){
				$url = $this->settings->web_url;
			}
			header('Location:'.$url);
			die();
		}
		public function Paginate($data = []){
			if(($data['current_page'] > $data['total_pages']) || ($data['current_page'] < 1 || $data['total_pages'] == 1)) return;
			$pagination = '<div class="pagination-box-row">
				<p>Page '.$data['current_page'].' of '.$data['total_pages'].'</p>							
				<ul class="pagination">
			';
			if($data['current_page'] > 1){
				$pagination .= '<li><a href="'.str_replace('{number}', 1, $data['url']).'">1</a></li>';
			}
			if(($data['current_page'] - $data['pages_per_side']) > $data['pages_per_side']){
				$pagination .= '<li><a class="disabled" href="javascript:void(0);">...</a></li>';
			}
			$right_limit = (($data['current_page'] + $data['pages_per_side']) < $data['total_pages']) ? $data['pages_per_side'] : (($data['pages_per_side'] * 2) + 2);
			for($i = ($data['current_page'] - $right_limit); $i < $data['current_page'];$i++){
				if($i < 2) continue;
				$pagination .= '<li><a href="'.str_replace('{number}', $i, $data['url']).'">'.$i.'</a></li>';
			}
			$left_limit = (($data['current_page'] - $data['pages_per_side']) < $data['pages_per_side']) ? (($data['pages_per_side'] * 2) + 2) : $data['pages_per_side'];
			for($i = $data['current_page'];$i <= ($data['current_page'] + $left_limit);$i++){
				if($i > $data['total_pages']) continue;
				$active = ($data['current_page'] == $i) ? 'class="active"' : '';
				$pagination .= '<li '.$active.' ><a href="'.str_replace('{number}', $i, $data['url']).'">'.$i.'</a></li>';
			}
			if(($data['current_page'] + ($data['pages_per_side'] * 2)) < ($data['total_pages'] - 1)){
				$pagination .= '<li><a class="disabled" href="javascript:void(0);">...</a></li>';
			}
			if($data['total_pages'] != (($data['pages_per_side'] * 2) + 2)){
				if($data['current_page'] < ($data['total_pages'] - $data['pages_per_side'])){
					$pagination .= '<li><a href="'.str_replace('{number}', $data['total_pages'], $data['url']).'" >'.$data['total_pages'].'</a></li>';
				}
			}
			$pagination .= '</ul></div>';
			return $pagination;
		}
		public function HtmlPurify() {
			$purifer_config = HTMLPurifier_Config::createDefault();
			$purifer_config->set('HTML.Allowed', 'iframe[src|width|height|frameborder], h1, h2, h3, h4, h5, h6, pre, p[style], strong, i, em, u, s, sub, sup, a[href|target|title], ol, ul, li, hr[class|width|size|noshade], span[class|style], font[face|size|color|style], blockquote, img[class|src|border|alt|title|hspace|vspace|width|height|align|name|style], table[align|border|cellpadding|cellspacing|class|style|summary], caption, tbody, tr, td[colspan], th');
			$purifer_config->set('HTML.SafeIframe', true);
			$purifer_config->set('URI.SafeIframeRegexp', '%^https://(www.youtube.com/embed/|player.vimeo.com/video/)%');
			$purifer_config->set('CSS.AllowedProperties', ['background-color', 'background-image', 'text-decoration', 'font-family', 'font-size', 'text-align', 'padding', 'padding-right', 'padding-top', 'padding-bottom', 'margin', 'margin-right', 'margin-top', 'margin-bottom', 'color', 'background', 'height', 'width']);
			$purifer_config->set('AutoFormat.RemoveEmpty', true);
			return new HTMLPurifier($purifer_config);
		}
	}
