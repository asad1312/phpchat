<?php

	defined('INSITE') or die('No direct script access allowed');

	class News extends Database{

		public function Add($data = []){
			if(!is_array($data) || !count($data)){
				return ['error' => 'System error!'];
			}
			$required_fields = ['title', 'text'];
			if(!CheckFields($required_fields, $data)){
				return ['error' => 'Complete all required fields!'];
			}
			$time = time();
			$sth = $this->db->prepare("INSERT INTO ".SQL_WEB_DB.".cms_news (title, text, author, posted) VALUES (:title, :text, :author, :posted)");
			$sth->bindParam(':title', $data['title']);
			$sth->bindParam(':text', $data['text']);
			$sth->bindParam(':author', $_SESSION['username']);
			$sth->bindParam(':posted', $time, PDO::PARAM_INT);
			$sth->execute();
			return ['success' => 'News added!'];

		}

		public function Edit($data = []){
			if(!is_array($data) || !count($data)){
				return ['error' => 'System error!'];
			}
			$required_fields = ['title', 'text', 'id'];
			if(!CheckFields($required_fields, $data)){
				return ['error' => 'Complete all required fields!'];
			}
			$sth = $this->db->prepare("UPDATE ".SQL_WEB_DB.".cms_news SET title = :title, text = :text WHERE id = :id");
			$sth->bindParam(':title', $data['title']);
			$sth->bindParam(':text', $data['text']);
			$sth->bindParam(':id', $data['id'], PDO::PARAM_INT);
			$sth->execute();
			return ['success' => 'News edited!'];
		}

		public function GetById($id){
			$sth = $this->db->prepare("SELECT * FROM ".SQL_WEB_DB.".cms_news WHERE id = :id");
			$sth->bindParam(':id', $id, PDO::PARAM_INT);
			$sth->execute();
			$row = $sth->fetch();
			return $row;
		}

		public function Remove($id){
			$sth = $this->db->prepare("DELETE FROM ".SQL_WEB_DB.".cms_news WHERE id = :id");
			$sth->bindParam(':id', $id, PDO::PARAM_INT);
			$sth->execute();
			return ['success' => 'News deleted!'];
		}

		public function GetAll(){
			$sth = $this->db->query("SELECT * FROM ".SQL_WEB_DB.".cms_news ORDER BY id DESC");
			$row = $sth->fetchAll();
			return $row;
		}

		public function GetCount(){
			$sth = $this->db->query("SELECT COUNT(*) AS count FROM ".SQL_WEB_DB.".cms_news");
			$row = $sth->fetch();
			return $row['count'];
		}

		public function GetList($start, $end){
			$sth = $this->db->prepare("SELECT * FROM ".SQL_WEB_DB.".cms_news ORDER BY `posted` DESC LIMIT :news_per_page OFFSET :offset");
			$sth->bindParam(':offset', $start, PDO::PARAM_INT);
			$sth->bindParam(':news_per_page', $end, PDO::PARAM_INT);
			$sth->execute();
			$row = $sth->fetchAll();
			return $row;
		}

	}
