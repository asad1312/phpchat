<?php
defined('INSITE') or die('No direct script access allowed');
class Chat extends Database {
    public $channels = [];  // channels = rooms;
    public $messages = [];
    private function GetOnlineUsers($channel) {
        $timestamp = strtotime('now +15 minutes');
        $timestamp2 = strtotime('now -15 minutes');
        $sth = $this->db->prepare("SELECT COUNT(*) AS `online` FROM ".SQL_WEB_DB.".`users` WHERE `currentChannel` = :channel AND `lastActivity` <= :time AND `lastActivity` >= :time2 AND `lastActivity` != 0");
        $sth->execute([':time' => $timestamp, ':time2' => $timestamp2, ':channel' => $channel]);
        if($sth->rowCount()) {
            return ($sth->fetch()['online']);
        }
        return 0;
    }
    public function getChannels() {
        $sth = $this->db->query("SELECT * FROM ".SQL_WEB_DB.".`channels` ORDER BY `id` ASC");
        if($sth->rowCount()) {
            $row = $sth->fetchAll();
            foreach($row as $key => $val) {
                $this->channels[$key] = [
                    'id' => (int)$val['id'],
                    'title' => htmlspecialchars($val['title']),
                    'icon' => htmlspecialchars($val['icon']),
                    'current_users' => $this->GetOnlineUsers($val['id']),
                    'status' => (isset($_SESSION['room']) && $_SESSION['room'] == $val['id'] ? 'active' : '')
                ];
            }
        }
        return $this->channels;
    }
    public function getDefaultRoom() {
        $sth = $this->db->query("SELECT `id` FROM ".SQL_WEB_DB.".`channels` ORDER BY `id` ASC LIMIT 1");
        if($sth->rowCount()) {
            return ($sth->fetch())['id'];
        }
        return 1;
    }
    public function getChannel($id) {
        $sth = $this->db->prepare("SELECT * FROM ".SQL_WEB_DB.".`channels` WHERE `id` = :id");
        $sth->execute([':id' => $id]);
        if($sth->rowCount()) {
            return ($sth->fetch());
        }
        return null;
    }
    public function getMessages($id = 0) {
        if($id == 0 || empty($id)) {
            return ['error' => 'unknown channel'];
        }
        $channel_info = $this->getChannel($id);
        if(!is_array($channel_info)) {
            return ['error' => 'חדר לא תקין!'];
        }
        $sth = $this->db->prepare("SELECT * FROM ".SQL_WEB_DB.".`messages` WHERE `channel_id` = :id ORDER BY `time` DESC LIMIT 20");
        $sth->execute([':id' => $id]);
        if($sth->rowCount()) {
            $row = $sth->fetchAll();
            foreach($row as $key => $val) {
                $text_color = '333';
                if($val['color'] == 'ffffff') {
                    $text_color = '333';
                    $val['color'] = 'ddf';
                } elseif($val['color'] != 'ddf') {
                    $text_color = 'ffffff';
                }
                $this->messages[$key] = [
                    'id' => (int)$val['id'],
                    'username' => htmlspecialchars($val['username']),
                    'msg' => htmlspecialchars(json_decode($val['message'])),
                    'time' => htmlspecialchars(date("H:i", strtotime($val['time']))),
                    'color' => htmlspecialchars(trim($val['color'])),
                    'text_color' => htmlspecialchars(trim($text_color))
                ];
            }
        }
        return array_reverse($this->messages);
    }
    public function LoadChat($data = []) {
        if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
		$required_fields = ['channel_id'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
        $channel_info = $this->getChannel($data['channel_id']);
        if(!is_array($channel_info)) {
            return ['error' => 'חדר לא תקין!'];
        }
        $sth = $this->db->prepare("UPDATE ".SQL_WEB_DB.".`users` SET `currentChannel` = :channel_id WHERE `username` = :username");
        $sth->execute([':channel_id' => $data['channel_id'], ':username' => $_SESSION['username']]);
        $_SESSION['room'] = $data['channel_id'];
        (new Account)->UpdateActivity($_SESSION['username']);
        /*$chats = [
            1 => ['id' => 1, 'username' => 'test', 'msg' => 'my message', 'time' => '16:00'],
            2 => ['id' => 2, 'username' => 'בדיקה', 'msg' => 'ההודעה שלי', 'time' => '16:02'],
        ];*/
        return [
            'success' => 'חדר נטען! אנא המתן...',
            'room_info' => $this->getChannel($data['channel_id']),
            'messages' => $this->getMessages($data['channel_id']),
        ];
    }
    public function InsertMessage($data = []) {
        if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
		$required_fields = ['channel_id', 'color', 'message'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
        $channel_info = $this->getChannel($data['channel_id']);
        if(!is_array($channel_info)) {
            return ['error' => 'חדר לא תקין!'];
        }
        if(strlen($data['message']) > 80) {
            return ['error' => 'מקסימום תווים להודעה זה 80!'];
        }
        if(isset($_SESSION['debounce']) && $_SESSION['debounce'] > time()) {
            return ['error' => 'אנא המתן 3 שניות לפני שליחת הודעה נוספת!'];
        }
        $_SESSION['debounce'] = time() + 3;
        $data['message'] = json_encode($data['message']);
        $data['ip'] = getUserIpAddr();
        $sth = $this->db->prepare("INSERT INTO ".SQL_WEB_DB.".`messages` (`channel_id`, `username`, `message`, `color`, `knownIp`) VALUES (:channel_id, :username, :message, :color, :ip)");
        $sth->bindParam(':channel_id', $data['channel_id'], PDO::PARAM_INT);
        $sth->bindParam(':username', $_SESSION['username'], PDO::PARAM_STR);
        $sth->bindParam(':message', $data['message'], PDO::PARAM_STR);
        $sth->bindParam(':color', $data['color'], PDO::PARAM_STR);
        $sth->bindParam(':ip', $data['ip'], PDO::PARAM_STR);
        $sth->execute();
        return ['success' => 'sent'];
    }
    public function LoadUsers($data = []) {
        if (!is_array($data) || !count($data)) {
            return ['error' => ['System error!']];
        }
		$required_fields = ['channel_id'];
        if (!CheckFields($required_fields, $data)) {
            return ['error' => 'אנא מלא את כל השדות!'];
        }
        $channel_info = $this->getChannel($data['channel_id']);
        if(!is_array($channel_info)) {
            return ['error' => 'חדר לא תקין!'];
        }
        $timestamp = strtotime('now +15 minutes');
        $timestamp2 = strtotime('now -15 minutes');
        $sth = $this->db->prepare("SELECT `id`, `username`, `profileInfo` FROM ".SQL_WEB_DB.".`users` WHERE `lastActivity` <= :time AND `lastActivity` >= :time2 AND `lastActivity` != 0 AND `currentChannel` = :channel");
        $sth->execute([':time' => $timestamp, ':time2' => $timestamp2, ':channel' => $data['channel_id']]);
        if($sth->rowCount()) {
            $row = $sth->fetchAll();
            foreach($row as $key => $val) {
                $profileInfo = (json_decode($val['profileInfo'], true))['profile'];
                switch($profileInfo['gender']) {
                    case 1:
                        $icon = '<i class="fa fa-male" style="color: #2360ef;"></i>';
                        break;
                    case 2:
                        $icon = '<i class="fa fa-female" style="color: #ef2347;"></i>';
                        break;
                    case 3:
                        $icon = '<i class="fa fa-question-circle"></i>';
                        break;
                    default:
                        $icon = '<i class="fa fa-question-circle"></i>';
                }
                $row[$key]['gender_icon'] = $icon;
            }
            return ['users' => $row];
        }
    }
    public function OnlineUsers() {
        $timestamp = strtotime('now +15 minutes');
        $timestamp2 = strtotime('now -15 minutes');
        $sth = $this->db->prepare("SELECT COUNT(*) AS `online` FROM ".SQL_WEB_DB.".`users` WHERE `lastActivity` <= :time AND `lastActivity` >= :time2 AND `lastActivity` != 0");
        $sth->execute([':time' => $timestamp, ':time2' => $timestamp2]);
        if($sth->rowCount()) {
            return number_format(($sth->fetch()['online']));
        }
        return 1;
    }
}
