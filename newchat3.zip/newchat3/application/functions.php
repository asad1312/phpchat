<?php
	defined('INSITE') or die('No direct script access allowed');
	function Message($type, $text){
		$html = '';
		if($type == 'success'){
			$html .= '<div class="alert alert-success"><strong>בוצע!</strong>';
		}
		elseif($type == 'info'){
			$html .= '<div class="alert alert-info"><strong>שים לב!</strong>';
		}
		elseif($type == 'warning'){
			$html .= '<div class="alert alert-warning"><strong>אזהרה!</strong>';
		}
		else{
			$html .= '<div class="alert alert-danger"><strong>שגיאה!</strong>';
		}
		$html .= ' '.$text.'</div>';
		echo $html;
	}
	function CheckFields($required_fields, $data){
		$data = array_filter($data, 'strlen');
		foreach($required_fields as $key){
			if(!array_key_exists($key, $data)){
				return false;
			}
		}
		return true;
	}
	function SendEmail($email, $subject, $message){
		$mail = new PHPMailer;
		/*$mail->isSMTP();
		#$mail->SMTPDebug = 2;
		#$mail->Debugoutput = 'html';
		$mail->Host = SMTP_HOST;
		$mail->Port = SMTP_PORT;
		$mail->SMTPSecure = SMTP_SECURE;
		$mail->SMTPAuth = true;
		$mail->Username = SMTP_EMAIL;
		$mail->Password = SMTP_PASSWORD;*/
		$mail->setFrom(SMTP_EMAIL, SMTP_FROM);
		$mail->addAddress($email);
		$mail->Subject = $subject;
		$mail->isHTML(true);
		$mail->Body = $message;
		return $mail->send();
	}
	function getUserIpAddr() {
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
                  $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
                  $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        }
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($client, FILTER_VALIDATE_IP)){
            $ip = $client;
        } elseif(filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }
        return $ip;
    }
	function generateRandomString($length = 10) {
        return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
    }
    function password_encrypt($password) {
        $secret_key = '$6d1$5Hz';
        return hash('sha512', $password.$secret_key);
    }
     function encrypt_email($email) {
        $string = round(strlen($email) / 2);
        $encrypted = str_repeat('*', $string) . substr($email, +6);
        return htmlspecialchars($encrypted);
    }
    function emoji_to_unicode($emoji) {
        return json_encode($emoji);
    }
    function verify_password($password, $hashed_password) {
        $secret_key = '$6d1$5Hz';
        $verify = hash('sha512', $password.$secret_key);
        return ($verify === $hashed_password);
    }
	function decrypt($string) {
        $output         = false;
        $encrypt_method = "AES-256-CBC";
        $secret_key     = 'secretKey121';
        $secret_iv      = 'iv';
        $key            = hash('sha256', $secret_key);
        $iv             = substr(hash('sha256', $secret_iv), 0, 16);    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
        $output         = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        return $output;
    }
    function encrypt($string) {
        if (empty($string)) {
            return $string;
        } else {
            $output         = false;
            $encrypt_method = "AES-256-CBC";
            $secret_key     = 'secretKey121';
            $secret_iv      = 'iv';
            $key            = hash('sha256', $secret_key);
            $iv             = substr(hash('sha256', $secret_iv), 0, 16);
            $output         = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
            $output         = base64_encode($output);
            return $output;
        }
    }
    function genders() {
        $genders = [
            1 => ['title' => 'זכר'],
            2 => ['title' => 'נקבה'],
            3 => ['title' => 'אחר']
        ];
        return $genders;
    }
    function areas() {
        $areas = [
            1 => ['title' => 'המרכז'],
            2 => ['title' => 'השרון'],
            3 => ['title' => 'השפלה'],
            4 => ['title' => 'ירושלים'],
            5 => ['title' => 'חיפה'],
            6 => ['title' => 'הצפון'],
            7 => ['title' => 'ב"ש והדרום'],
            8 => ['title' => 'אילת'],
            9 => ['title' => 'חו"ל']
        ];
        return $areas;
    }
	function writelog($logentry, $lgname){
        $log = '['.$_SERVER['REMOTE_ADDR'].'] '.$logentry.'';
        if(!is_dir("logs")){
            mkdir("logs");
        }
        $log_name = 'logs/'.$lgname.'_'.date("m-d-y").'.txt';
        $logfile = @fopen ($log_name, "a+");
        if ($logfile){
            fwrite ($logfile, "[".date ("h:iA")."] $log\r\n");
            fclose ($logfile);
        }
    }
    function LoadTxt($file = 'privacy') {
        if(file_exists(BASE_DIR.'application/config/'.$file.'.txt')) {
            $file = file_get_contents(BASE_DIR.'application/config/'.$file.'.txt');
            return nl2br(strip_tags(trim($file)));
        } else {
            return $file.' not exists!';
        }
    }