<?php
  defined('INSITE') or die('No direct script access allowed');
	if($Account->IsLogged()){
		$user_info = $Account->UserInfo($_SESSION['username']);
		if(!is_array($user_info)) {
			session_destroy();
			$Website->Redirect();
		}
	} else {
		/*if(isset($_POST['login_user']) && isset($_POST['login_password'])) {
			$login_user = trim($_POST['login_user']);
			$login_password = trim($_POST['login_password']);
			$login = $Account->Login($login_user, $login_password);
			if(isset($login['success'])) {
				$Website->Redirect();
			}
		}*/
	}
