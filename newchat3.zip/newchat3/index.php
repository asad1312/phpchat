<?php
ini_set('display_errors',false);
ini_set('error_reporting', E_ALL );

	ob_start('ob_gzhandler');

	session_start();
	if(!file_exists('config.php')){
		header('Location:'.$_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'].'application/install');
		die();
	}
	
	require 'autoloader.php';
	$Website = new Website;
	$Account = new Account;

    $Website->AjaxToken();

	require 'application/user.php';
	
	$path = preg_replace('/\?.*/', '', $_SERVER['REQUEST_URI']);
	if(!empty(WEB_PATH)){
		$path = str_replace('/'.WEB_PATH.'/', '', $path);
	}
	$paths = explode('/', $path);
	$paths = array_filter($paths);
	$paths = array_values($paths);
	if(!$Account->IsLogged() && !isset($paths[0])) {
		$paths[0] = 'dashboard';
	} elseif(!isset($paths[0]) && $Account->IsLogged()) {
		$paths[0] = 'home';
	} elseif(isset($paths[0])) {
	    $paths[0] = $paths[0];
	}

	$folder = '';
	$page = $paths[0];
	if(count($paths) >= 2){
		if(in_array($page, ['account', 'admin'])){
			$folder = '/'.$paths[0];
			$page = $paths[1];
		}
	}

	if(file_exists('pages'.$folder.'/'.$page.'.php')){
        require 'pages'.$folder.'/'.$page.'.php';
	}
	else{
		$page = 'Unknown page';
		require 'pages/404.php';
	}
	ob_end_flush();
