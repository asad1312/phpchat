<?php 
	defined('INSITE') or die('No direct script access allowed');
	require TEMPLATE_DIR.'header.php';
?>
	<div class="widget widgetRooms" id="rooms">
		<h1 class="main-title">חדרים (<span id="totalRooms"></span>)</h1>
		<!--<div class="row allRooms">
			<ul>
				<li class="roomObject">
					<a href="#" class="roomNav">
						<div class="row">
							<div class="col-md-4 col-4 roomIcon">
								<div class="roomCircle">
									<i class="fa fa-user"></i>
								</div>
							</div>
							<div class="col-md-8 col-8 roomInfo">
								<h4>כללי</h4>
								<h6>22</h6>
							</div>
						</div>
					</a>
				</li>
			</ul>
		</div>!-->
		<div id="renderRooms">
			<span class="loader mb-2"></span>
			<strong class="d-block w-100 text-center">אנא המתן...</strong>
		</div>
	</div>
	<div class="widget roomWidget active" id="chat">
		<h1 class="main-title" id="page-title">אנא המתן</h1>
		<div id="messages" class="roomMessages">
			<!--<div class="row msg">
				<div class="user">username</div>
				<div class="col-md-2 col-2 profileImage">
					test
				</div>
				<div class="col-md-10 col-10 msgInfo">
					<div class="row">
						<div class="col-md-8 col-8 text">
							ssss
						</div>
						<div class="col-md-4 col-4">
							<time>16:00</time>
						</div>
					</div>
				</div>
			</div>!-->
			<span class="loader"></span>
			
		</div>
		<div class="sendMessage col-md-12 col-12">
			<form id="sendMsg" action="" method="POST">
				<div class="row align-items-center">
					<div class="col-auto emoji">
						<button class="btnEmoji" id="selectEmoji" type="button"><i class="fa fa-heart"></i></button>
					</div>
					<div class="col messageInput">
						<input type="text" id="inputMsg" class="mainInput" name="message" placeholder="הודעה" required></input>
					</div>
					<div class="col-auto d-flex align-items-center sendButtons">
						<button class="btnPaint" id="selectPaint" type="button"><i class="fa fa-paint-brush"></i></button>
						<button class="btn btn-primary" type="submit">שלח</button>
					</div>
				</div>
			</form>
		</div>
	</div>
	<div class="widget widgetUsers" id="users">
		<h1 class="main-title">משתמשים בחדר (<span id="totalUsers"></span>)</h1>
		<div class="users" id="renderUsers">
		
		</div>
	</div>
<?php
require TEMPLATE_DIR.'footer.php';
