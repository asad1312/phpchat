<?php 
	defined('INSITE') or die('No direct script access allowed');
	require GUEST_TEMPLATE_DIR.'header.php';
?>
    <div class="right">
        <div class="logo">
            <img src="<?php echo $Website->settings->web_url;?>/assets/<?php echo GUEST_TEMPLATE_NAME;?>/assets/images/logo.svg" alt="logo" class="img-fluid" />
        </div>
        <div class="content">
            <h1 class="main-title">ברוכים הבאים ל<?php echo htmlspecialchars(SMTP_FROM);?></h1>
            <h4>אתר הצ'אט המוביל בישראל</h4>
        </div>
    </div>
    <div class="left">
        <div class="panel" id="panel">
            <h1 class="main-title">התחברות</h1>
            <form action="" method="POST" id="login_form">
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <input type="text" class="form-control" name="username" id="userIdentifier" placeholder="שם משתמש " required />
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <input type="password" class="form-control" name="password" placeholder="סיסמא" required />
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <button class="btn login-btn w-100" type="submit">התחברות</button>
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <button class="btn btn-primary w-100 switch" type="button" data-div="guest_form">התחברות כאורח</button>
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <button class="btn register-btn w-100 switch" data-div="register_form">הרשמה</button>
                </div>
                <a href="#" class="text-dark text-center">שכחת סיסמה?</a>
            </form>
            <form action="" method="POST" id="register_form">
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <input type="text" class="form-control" name="username" id="registerUsername" placeholder="שם משתמש" minlength="4" maxlength="32" required />
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <input type="email" class="form-control" name="email" id="registerEmail" placeholder="דואר אלקטרוני" required style="text-align: right;" />
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <input type="password" class="form-control" name="password" placeholder="סיסמא" minlength="4" maxlength="64" required />
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <input type="password" class="form-control" name="confirmPassword" placeholder="אישור סיסמא" minlength="4" maxlength="64" required />
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <div class="row">
                        <div class="col-md-4 mx-auto">
                            <select class="form-control" name="gender" id="gender" required>
                                <option value="" disabled selected>מין</option>
                                <?php foreach(genders() as $key => $val) { ?>
                                    <option value="<?php echo (int)$key;?>"><?php echo htmlspecialchars($val['title']);?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-md-4 mx-auto">
                            <select class="form-control" name="age" id="age" required>
                                <option value="" disabled selected>גיל</option>
                                <?php 
                                    for($i = 18; $i <= 120; $i++) {
                                        echo '<option value="'.(int)$i.'">'.(int)$i.'</option>';
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4 mx-auto">
                            <select class="form-control" name="area" id="area" required>
                                <option value="" disabled selected>אזור</option>
                                <?php foreach(areas() as $key => $val) { ?>
                                    <option value="<?php echo (int)$key;?>"><?php echo htmlspecialchars($val['title']);?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 mx-auto mt-3 mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="checkRules" name="rules">
                        <label class="form-check-label" for="checkRules">
                            <strong class="text-dark">בלחיצה על הרשמה אני מאשר שקראתי ואישרתי את <a href="#rules" id="getRules" class="text-white">תנאי השימוש</a></strong>
                        </label>
                    </div>
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <button class="btn login-btn w-100" type="submit">לשלב הבא</button>
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <button class="btn register-btn w-100 switch" data-div="login_form">כבר יש לי חשבון</button>
                </div>
                <a href="#" class="text-dark text-center">שכחת סיסמה?</a>
            </form>
            <form action="" method="POST" id="guest_form" style='display: none;'>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <input type="text" class="form-control" name="username" id="registerUsername" placeholder="שם משתמש" minlength="4" maxlength="32" required />
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <div class="row">
                        <div class="col-md-4 mx-auto">
                            <select class="form-control" name="gender" id="gender" required>
                                <option value="" disabled selected>מין</option>
                                <?php foreach(genders() as $key => $val) { ?>
                                    <option value="<?php echo (int)$key;?>"><?php echo htmlspecialchars($val['title']);?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-md-4 mx-auto">
                            <select class="form-control" name="age" id="age" required>
                                <option value="" disabled selected>גיל</option>
                                <?php 
                                    for($i = 18; $i <= 120; $i++) {
                                        echo '<option value="'.(int)$i.'">'.(int)$i.'</option>';
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4 mx-auto">
                            <select class="form-control" name="area" id="area" required>
                                <option value="" disabled selected>אזור</option>
                                <?php foreach(areas() as $key => $val) { ?>
                                    <option value="<?php echo (int)$key;?>"><?php echo htmlspecialchars($val['title']);?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 mx-auto mt-3 mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="checkRules" name="rules">
                        <label class="form-check-label" for="checkRules">
                            <strong class="text-dark">בלחיצה על הרשמה אני מאשר שקראתי ואישרתי את <a href="#rules" id="getRules" class="text-white">תנאי השימוש</a></strong>
                        </label>
                    </div>
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <button class="btn login-btn w-100" type="submit">לשלב הבא</button>
                </div>
                <div class="col-md-8 ms-auto mt-3 mb-3">
                    <button class="btn register-btn w-100 switch" data-div="login_form">כבר יש לי חשבון</button>
                </div>
                <a href="#" class="text-dark text-center">שכחת סיסמה?</a>
            </form>
        </div>
    </div>
<?php
	require GUEST_TEMPLATE_DIR.'footer.php';

