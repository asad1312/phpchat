<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Terms</title>
<link href="Content/bootstrap.css" rel="stylesheet" />
</head>
<body dir="rtl" style="text-align:right;">
<div class="container">
<div>
<h1 style="text-align:center;">
 מדיניות הפרטיות קוקו צ'אט
