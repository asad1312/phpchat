<?php 
	defined('INSITE') or die('No direct script access allowed');
	require GUEST_TEMPLATE_DIR.'header.php';
?>
    <div class="right col-md-6">
        <div class="logo">
            <img src="<?php echo $Website->settings->web_url;?>/assets/<?php echo GUEST_TEMPLATE_NAME;?>/assets/images/logo.svg" alt="logo" class="img-fluid" />
        </div>
        <div class="content">
            <h1 class="main-title">ברוכים הבאים ל<?php echo htmlspecialchars(SMTP_FROM);?></h1>
            <h4>אתר ההכרויות המוביל בישראל</h4>
            <div class="arrow mobile-only bounce">
                <a href="#panel">
                    <i class="fa fa-arrow-down"></i>
                </a>
            </div>
        </div>
    </div>
    <div class="left col-md-6">
        <div class="panel" id="panel">
            <h1 class="main-title">תנאי שימוש</h1>
            <hr/>
            <?php echo LoadTxt('terms');?>
        </div>
    </div>
<?php
	require GUEST_TEMPLATE_DIR.'footer.php';

