<?php
	defined('INSITE') or die('No direct script access allowed');
	$Account->LogOut();
	$Website->Redirect();