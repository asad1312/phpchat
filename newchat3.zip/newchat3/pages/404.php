<?php 

	defined('INSITE') or die('No direct script access allowed');

	require TEMPLATE_DIR.'header.php';

	echo Message('warning', 'Sorry, this page is removed or not exists!');

	require TEMPLATE_DIR.'footer.php';

