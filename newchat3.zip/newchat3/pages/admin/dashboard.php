<?php
	defined('INSITE') or die('No direct script access allowed');
	require ADMINTHEME_DIR.'header.php';
	if($Account->IsAdmin()){
		$Admin = new Admin;
		$latestUsers = $Admin->getLatestUsers();
?>
    <div class="col-lg-12">
        <strong><?php echo $Website->settings->web_title;?></strong>
		<div class="row mt-4">
			<div class="col-6 col-lg-6 col-xl-6">
				<div class="card">
					<div class="card-body">
						<h5 class="card-title mb-2">המשתמשים החדשים ביותר</h5>
						<hr/>
						<div class="table-responsive">
							<?php 
								if(count($latestUsers)) {
							?>
								<table class="table text-center table-striped">
									<thead>
										<tr>
											<th scope="col">#</th>
											<th scope="col">שם משתמש</th>
											<th scope="col">מייל</th>
											<th scope="col">כתובת אייפי</th>
											<th scope="col">נוצר בתאריך</th>
										</tr>
									</thead>
									<tbody>
										<?php foreach($latestUsers as $key => $val) { 
										?>
											<tr>
												<td><?php echo (int)$key+1;?></td>
												<td><strong><?php echo $val['username'];?></strong></td>
												<td><strong><?php echo $val['email'];?></strong></td>
												<td><?php echo htmlspecialchars($val['lastIp']);?></td>
												<td><?php echo htmlspecialchars($val['createDate']);?></td>
											</tr>
										<?php } ?>         
									</tbody>
								</table>
							<?php 
								} else {
									echo Message('info', 'לא נמצאו אתרים!');
								}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
<?php
	} else{
		header("Location: ".$Website->settings->web_url."/admin/dashboard");
	}
	require ADMINTHEME_DIR.'footer.php';
