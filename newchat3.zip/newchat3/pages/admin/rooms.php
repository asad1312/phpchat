<?php
	defined('INSITE') or die('No direct script access allowed');
	require ADMINTHEME_DIR.'header.php';
	if($Account->IsAdmin()){
        $Admin = new Admin;
        $action = isset($paths[2]) ? trim(strtolower($paths[2])) : 'view';
        switch($action) {
            case 'edit':
                $client_id = (isset($paths[3])) ? (int)$paths[3] : 0;
                $client_info = $Admin->getClientInfo($client_id);
                break;
            case 'view':
            default:
                $allChannels = (new Chat)->getChannels();
                break;
        }
?>
    <?php
        switch($action) {
            case 'edit':
                if(!isset($client_info['error'])) {
                    $clientSites = $client_info['sites'];
                    $availableCodes = $client_info['available_codes'];
                } else {
                    echo Message('error', $client_info['error']);
                }
    ?>
    <?php
                break;
            case 'view':
            default:
    ?>
        <div class="col-lg-12 col-md-12 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">פתיחת חדר חדש</h5>
                    <form action="" method="POST" id="createRoom">
                        <div class="form-group row">
                            <label for="inputRoom" class="col-sm-2 col-form-label">כותרת חדר</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="inputRoom" name="title" minlength="4" maxlength="255" placeholder="הכנס בשדה זה את שם החדר" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="icon" class="col-sm-2 col-form-label">אייקון</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control selector icp icp-auto" data-input-search="true" id="icon" name="icon" required>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-primary mb-0">המשך</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-12 col-md-12 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">חדרים קיימים</h5>
                    <div class="table-responsive">
                        <?php 
                            if(count($allChannels)) {
                        ?>
                            <table class="table text-center table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">שם חדר</th>
                                        <th scope="col">אייקון</th>
                                        <th scope="col">פעולה</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($allChannels as $key => $val) { ?>
                                        <tr>
                                            <td><?php echo $val['id'];?></td>
                                            <td><?php echo $val['title'];?></td>
                                            <td><i class="<?php echo $val['icon'];?>"></i></td>
                                            <td>
                                                <div class="col-md-6 col-6 text-center m-auto">
                                                    <button id="deleteRoom" data-room="<?php echo (int)$val['id'];?>" class="btn btn-danger text-white">מחיקה</button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php } ?>         
                                </tbody>
                            </table>
                        <?php 
                            } else {
                                echo Message('info', 'לא נמצאו לקוחות!');
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    <?php
            break;
        }
    ?>
<?php
	} else{
		header("Location: ".$Website->settings->web_url."/admin/dashboard");
	}
	require ADMINTHEME_DIR.'footer.php';
