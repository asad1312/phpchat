<?php
	defined('INSITE') or die('No direct script access allowed');
	require ADMINTHEME_DIR.'header.php';
	$return_website = [];
	if($Account->IsAdmin()){
		if(isset($_POST['website']) && count($_POST['website'])){
			$return_website = $Website->SaveSettings($_POST['website']);
		}
		if(isset($return_website['error'])){
			 Message('error', array_shift($return_website['error']));
		 }
		if(isset($return_website['success'])){
			 Message('success', $return_website['success']);
			 echo '<meta http-equiv="refresh" content="2">';
		}
?>
<div class="col-lg-12 col-md-12 mb-4">
	<div class="card">
		<div class="card-body">
			<h5 class="card-title">ניהול הגדרות אתר</h5>
			<form action="<?php echo $Website->settings->web_url;?>/admin/settings" method="POST">
				<div class="form-group row">
					<label for="webLink" class="col-sm-2 col-form-label">קישור אתר</label>
					<div class="col-sm-10">
						<input type="text" name="website[web_url]" id="webLink" class="form-control" value="<?php echo $Website->settings->web_url;?>" required>
					</div>
				</div>
				<div class="form-group row">
					<label for="webTitle" class="col-sm-2 col-form-label">כותרת אתר</label>
					<div class="col-sm-10">
						<input type="text" name="website[web_title]" id="webTitle" class="form-control" value="<?php echo $Website->settings->web_title;?>" required>
					</div>
				</div>
				<div class="form-group row">
					<label for="recaptchaEnable" class="col-sm-2 col-form-label">שימוש ב Recaptcha V2</label>
					<div class="col-sm-10">
						<select class="form-control" name="website[captcha_enable]" class="form-control" id="recaptchaEnable" required>
							<option value="0" <?php if((int)$Website->settings->captcha_enable == 0) { echo "selected";}?>>No</option>
							<option value="1" <?php if((int)$Website->settings->captcha_enable == 1) { echo "selected";}?>>Yes</option>
						</select>
					</div>
				</div>
				<div class="form-group row">
					<label for="siteKey" class="col-sm-2 col-form-label">מזהה אתר (Recaptcha site key)</label>
					<div class="col-sm-10">
						<input type="text" name="website[captcha_site_key]" id="siteKey" class="form-control" value="<?php echo $Website->settings->captcha_site_key;?>" required>
					</div>
				</div>
				<div class="form-group row">
					<label for="privateKey" class="col-sm-2 col-form-label">מזהה אתר (Recaptcha private key)</label>
					<div class="col-sm-10">
						<input type="text" name="website[captcha_secret_key]" id="siteKey" class="form-control" value="<?php echo $Website->settings->captcha_secret_key;?>" required>
					</div>
				</div>
				<div class="form-group row mb-0">
					<div class="col-md-6">
						<button type="submit" class="btn btn-primary mb-0">שמירה</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<?php
	}
	else{
		echo Message('error', 'Access denied!');
	}
	require ADMINTHEME_DIR.'footer.php';
