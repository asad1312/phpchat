<?php
	/*== SQL SETTINGS ===*/
	define('SQL_HOST', 'localhost');	// mysqli
	define('SQL_PDO', 'mysqli');	// mysqli
	define('SQL_WEB_DB', 'torchatt_new_db');	// db name of web DB (mysqli)
	define('SQL_USER', 'torchatt_new_db');		// user for mysqli
	define('SQL_PASSWORD', 'sdZKhkzkmJPXDZJf');	// pass for mysqli

	/*== WEBSITE SETTINGS ===*/
	define('ADMIN_LIST', 'chen');	//Separate by comma
	define('SHOW_ERRORS', true);
	define('WEB_PATH', 'newchat3');	//Leave empty if website not in subdirectory
	define('DS', DIRECTORY_SEPARATOR);
	define('BASE_DIR', __DIR__.DS);
	define('TEMPLATE_NAME', 'default');
	define('TEMPLATE_DIR', BASE_DIR.'assets/'.TEMPLATE_NAME.'/');
	define('GUEST_TEMPLATE_NAME', 'guests');
	define('GUEST_TEMPLATE_DIR', BASE_DIR.'assets/'.GUEST_TEMPLATE_NAME.'/');
	define('ADMINTHEME_DIR', BASE_DIR.'assets/admincp/');
	
	/*== SMTP SETTINGS ===*/
	define('USE_SMTP', true);
	define('SMTP_HOST', 'ukcpanel1.webhosted.uk');
	define('SMTP_PORT', '465');
	define('SMTP_SECURE', 'ssl');
	define('SMTP_EMAIL', 'noreply@torchatt.com');
	define('SMTP_PASSWORD', '');
	define('SMTP_FROM', 'קוקו צאט');

	/*== EMAIL SETTINGS ===*/
	define('CONTACT_EMAIL', 'email@gmail.net');

	/*== DO NOT TOUCH ===*/
	if(!defined('INSITE')){
		define('INSITE', true);
	}