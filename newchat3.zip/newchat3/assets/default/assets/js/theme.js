$(document).ready(function () {
    "use strict";
    $.ajaxSetup({
        type: "post",
        url: App.base_url + "ajax_helper.php",
        headers: {
            token: $('meta[name="token"]').attr("content"),
            is_ajax: 1,
        },
        dataType: "json",
        error: function (jqXHR, exception) {
            if (jqXHR.status == 404) {
                alert("Requested page not found. [404]");
            } else if (jqXHR.status == 500) {
                alert("Internal Server Error [500]");
            } else if (jqXHR.status == "429") {
                alert("Refresh page and try again! [429]");
            } else if (exception === "parsererror") {
                alert(jqXHR.responseText);
            } else if (exception === "timeout") {
                alert("Time out error");
            } else if (exception === "abort") {
                alert("Ajax request aborted.");
            }
        },
    });
    var overlay = $("#overlay");
    var open_modal = $("[data-toggle='modal']");
    var close = $(".close, #overlay");
    var modal = $(".modal");
    open_modal.click(function (event) {
        event.preventDefault();
        var div = $(this).data("target");
        overlay.fadeIn(400, function () {
            $(div)
                .addClass("show")
                .animate({ opacity: 1, top: "0px" }, 200)
                .show();
        });
    });
    close.click(function (e) {
        e.preventDefault();
        modal.animate({ opacity: 0, top: "0px" }, 200, function () {
            $(this).css("display", "none").removeClass("show");
            overlay.fadeOut(400);
        });
    });
    $(".switchButtons .btn").click(function () {
        $(".switchButtons .btn").removeClass("active");
        $(this).addClass("active");
        $(".siteContent .widget").removeClass("active");
        $("#" + $(this).attr("data-widget")).addClass("active");
    });
});
