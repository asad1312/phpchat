<?php
    defined('INSITE') or die('No direct script access allowed');
    if(!$Account->IsLogged()) {
        $Website->Redirect();
    } else {
        $user_info = $user_info;
    }
?>
                </div>
            </div>
        </main>
        <footer>
            <div class="container xl-container">
                <div class="content row">
                    <div class="col-md-12 col-12"><?php echo SMTP_FROM;?></div>
                    <div class="col-md-12 col-12">
                        <ul class="p-0 m-0" style="list-style: none;">
                            <li><a href="<?php echo $Website->settings->web_url;?>/terms" target="_blank">תנאי שימוש</a></li>
                            <li><a href="<?php echo $Website->settings->web_url;?>/privacy" target="_blank">מדיניות פרטיות</a></li>
                            <li><a href="mailto:<?php echo CONTACT_EMAIL;?>">צור קשר</a></li>
                        </ul>
                    </div>
                </div>
            </div>            
            <div class="modal fade" id="settings" tabindex="-1" role="dialog" aria-labelledby="settingsLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header mb-0">
                            <h5 class="modal-title" id="settingsLabel">הגדרות</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <?php if($Account->IsAdmin()) { ?>
                                <div class="col-md-12 col-12 m-0 m-auto text-center">
                                    <a href="<?php echo $Website->settings->web_url;?>/admin/dashboard" class="btn btn-primary w-100 d-block m-0 m-auto text-center">אדמין פאנל</a>
                                </div>
                            <?php } ?>
                            <ul class="nav nav-tabs <?php echo ($Account->IsAdmin() ? 'mt-4' : '');?>" id="myTab" role="tablist">
                                <?php if($user_info['guest'] == 0) { ?>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="login-tab" data-bs-toggle="tab" data-bs-target="#loginInfo" type="button" role="tab" aria-controls="loginInfo" aria-selected="true">ניהול פרטי התחברות</button>
                                    </li>
                                <?php } ?>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link <?php echo ($user_info['guest'] == 1 ? 'active' : '');?>" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">ניהול פרופיל</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="other-tab" data-bs-toggle="tab" data-bs-target="#other" type="button" role="tab" aria-controls="other" aria-selected="false">ניהול מידע כללי</button>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <?php if($user_info['guest'] == 0) { ?>
                                    <div class="tab-pane fade show active" id="loginInfo" role="tabpanel" aria-labelledby="login-tab">
                                        <h5 class="modal-title mb-3 mt-3">עדכון מייל</h5>
                                        <form action="/" method="POST" id="updateMail" class="mb-5">
                                            <div class="form-group mb-2">
                                                <label for="currentEmail" class="pb-2">מייל נוכחי</label>
                                                <input type="email" class="form-control text-right" name="currentEmail" id="currentEmail" placeholder="<?php echo encrypt_email($user_info['email']);?>" required>
                                            </div>
                                            <div class="form-group mb-3">
                                                <label for="newEmail" class="pb-2">מייל חדש</label>
                                                <input type="email" class="form-control text-right" name="newEmail" id="newEmail" placeholder="הקלד מייל חדש" required>
                                            </div>
                                            <div class="col-md-12 col-12 m-auto m-0 text-center">
                                                <button class="btn btn-primary w-100" type="submit">עדכון</button>
                                            </div>
                                        </form>
                                        <hr/>
                                        <h5 class="modal-title mb-3 mt-4">עדכון סיסמה</h5>
                                        <form action="/" method="POST" id="updatePassword">
                                            <div class="form-group mb-2">
                                                <label for="currentPassword" class="pb-2">סיסמה נוכחית</label>
                                                <input type="password" class="form-control text-right" name="currentPassword" id="currentPassword" placeholder="הקלד סיסמה נוכחית" minlength="4" maxlength="64" required>
                                            </div>
                                            <div class="form-group mb-2">
                                                <label for="newPassword" class="pb-2">סיסמה חדשה</label>
                                                <input type="password" class="form-control text-right" name="newPassword" id="newPassword" placeholder="הקלד סיסמה חדשה" minlength="4" maxlength="64" required>
                                            </div>
                                            <div class="form-group mb-3">
                                                <label for="confirmPassword" class="pb-2">אישור סיסמה חדשה</label>
                                                <input type="password" class="form-control text-right" name="confirmPassword" id="confirmPassword" placeholder="חזור על הסיסמה החדשה" minlength="4" maxlength="64" required>
                                            </div>
                                            <div class="col-md-12 col-12 m-auto m-0 text-center">
                                                <button class="btn btn-primary w-100" type="submit">עדכון</button>
                                            </div>
                                        </form>
                                    </div>
                                <?php } ?>
                                <div class="tab-pane fade <?php echo ($user_info['guest'] == 1 ? 'show active' : '');?>" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                    <h5 class="modal-title mb-3 mt-4">עדכון אזור</h5>
                                    <form action="/" method="POST" id="updateArea">
                                        <label for="area" class="pb-2">אזור</label>
                                        <select class="form-control mb-3" name="area" id="area" required>
                                            <option value="" disabled selected>אזור</option>
                                            <?php foreach(areas() as $key => $val) { ?>
                                                <option value="<?php echo (int)$key;?>" <?php echo ($user_info['profileInfo']['area'] == $key ? 'selected' : '');?>><?php echo htmlspecialchars($val['title']);?></option>
                                            <?php } ?>
                                        </select>
                                        <div class="col-md-12 col-12 m-auto m-0 text-center">
                                            <button class="btn btn-primary w-100" type="submit">עדכון</button>
                                        </div>
                                    </form>
                                    <hr/>
                                    <h5 class="modal-title mb-3 mt-4">עדכון גיל</h5>
                                    <form action="/" method="POST" id="updateAge">
                                        <label for="age" class="pb-2">גיל</label>
                                        <select class="form-control mb-3" name="age" id="age" required>
                                            <option value="" disabled selected>גיל</option>
                                            <?php 
                                                for($i = 18; $i <= 120; $i++) {
                                                    $selected = ($user_info['profileInfo']['age'] == $i ? 'selected' : '');
                                                    echo '<option value="'.(int)$i.'" '.$selected.'>'.(int)$i.'</option>';
                                                }
                                            ?>
                                        </select>
                                        <div class="col-md-12 col-12 m-auto m-0 text-center">
                                            <button class="btn btn-primary w-100" type="submit">עדכון</button>
                                        </div>
                                    </form>
                                    <hr/>
                                    <h5 class="modal-title mb-3 mt-4">עדכון מין</h5>
                                    <form action="/" method="POST" id="updateGender">
                                        <label for="gender" class="pb-2">מין</label>
                                        <select class="form-control mb-3" name="gender" id="gender" required>
                                            <option value="" disabled selected>מין</option>
                                            <?php foreach(genders() as $key => $val) { ?>
                                                <option value="<?php echo (int)$key;?>" <?php echo ($user_info['profileInfo']['gender'] == $key ? 'selected' : '');?>><?php echo htmlspecialchars($val['title']);?></option>
                                            <?php } ?>
                                        </select>
                                        <div class="col-md-12 col-12 m-auto m-0 text-center">
                                            <button class="btn btn-primary w-100" type="submit">עדכון</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane fade" id="other" role="tabpanel" aria-labelledby="other-tab">
                                    <h5 class="modal-title mb-3 mt-3">קצת עליי</h5>
                                    <form action="/" method="POST" id="updateAbout" class="mb-5">
                                        <div class="form-group mb-3">
                                            <label for="aboutMe" class="pb-2">קצת עליי (מידע על החשבון)</label>
                                            <textarea class="form-control text-right" name="aboutMe" id="aboutMe" placeholder="הקלד מייל חדש" rows="10" maxlength="500" required><?php echo $Website->HtmlPurify()->purify(($user_info['otherInfo']['about']));?></textarea>
                                        </div>
                                        <div class="col-md-12 col-12 m-auto m-0 text-center">
                                            <button class="btn btn-primary w-100" type="submit">עדכון</button>
                                        </div>
                                    </form>
                                    <hr/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="profileModal" tabindex="-1" role="dialog" aria-labelledby="profileLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header mb-0">
                            <h5 class="modal-title" id="profileLabel">פרופיל משתמש</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="col-12 col-md-12 col-lg-12 col-xl-12 justify-content-center text-center">
                                <div class="card" style="border-radius: 15px;">
                                    <div class="card-body p-4">
                                        <div class="d-block text-center text-black">
                                            <div class="d-block text-center">
                                                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-profiles/avatar-1.webp" alt="Generic placeholder image" class="img-fluid" style="width: 180px; border-radius: 10px;">
                                            </div>
                                            <div class="mt-3 w-100 m-0 p-0 d-block text-center">
                                                <h5 class="mb-1" id="profileUsername">{{username}}</h5>
                                                <hr/>
                                                <h5 class="mb-3">אודות</h5>
                                                <p class="mb-2 pb-1" style="color: #2b2a2a;" id="profileAbout">{{about}}</p>
                                                <hr/>
                                                <div class="row justify-content-center m-0 p-0" style="background-color: #efefef;">
                                                    <div class="col-md-4 col-4 text-center">
                                                        <p class="small text-muted mb-1">מין</p>
                                                        <p class="mb-0" id="profileGender">{{gender}}</p>
                                                    </div>
                                                    <div class="col-md-4 col-4 text-center">
                                                        <p class="small text-muted mb-1">אזור</p>
                                                        <p class="mb-0" id="profileArea">{{area}}</p>
                                                    </div>
                                                    <div class="col-md-4 col-4 text-center">
                                                        <p class="small text-muted mb-1">גיל</p>
                                                        <p class="mb-0" id="profileAge">{{age}}</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr/>
                                        </div>
                                        <div class="mt-3 w-100 m-0 p-0 d-block text-center row col-12">
                                            <button type="button" class="btn btn-outline-primary me-1 flex-grow-1 mb-3">שלח הודעה</button>
                                            <button type="button" class="btn btn-primary me-1 flex-grow-1 mb-3">הוסףף חבר</button>
                                            <button type="button" class="btn btn-danger flex-grow-1">חסום</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="emoji_display" class="alert alert-info my-3"></div>
        </footer>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="<?php echo $Website->settings->web_url;?>/assets/<?php echo TEMPLATE_NAME;?>/assets/js/jquery.minicolors.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/fuse.js/dist/fuse.js"></script>
        <script src="<?php echo $Website->settings->web_url;?>/assets/<?php echo TEMPLATE_NAME;?>/assets/js/emoji_keyboard.js"></script>
        <script src="<?php echo $Website->settings->web_url;?>/assets/<?php echo TEMPLATE_NAME;?>/assets/js/theme.js"></script>
        <script src="<?php echo $Website->settings->web_url;?>/assets/<?php echo TEMPLATE_NAME;?>/assets/js/ejs.js"></script>
        <script>
            const App = {
                base_url: '<?php echo $Website->settings->web_url;?>/',
                current_room: <?php echo (int)$_SESSION['room'];?>
            };
        </script>
        <script src="<?php echo $Website->settings->web_url;?>/assets/<?php echo TEMPLATE_NAME;?>/assets/js/app.min.js?v=<?php echo time();?>"></script>
        <script>
            $(document).on("submit", "#update_guest_user_name", function (e) {
                e.preventDefault();
                var form = $(this);
                $.ajax({
                    data:
                        $.param({ action: "update_guest_user_name" }) +
                        "&" +
                        $(form).serialize(),
                    beforeSend: function () {
                        $(".alert").remove();
                        $("<div class='alert alert-info' style='position:absolute' id='alert'>אנא המתן...</div>")
                            .hide()
                            .fadeIn(1500)
                            .insertBefore(form);
                    },
                    success: function (data) {
                            Swal.fire({
                            title: "Success",
                            text: "שישינוי השם משתמש שונה בהצלחה",
                            icon: "success"
                            });
                    },
                });
            });
        </script>
    </body>
</html>