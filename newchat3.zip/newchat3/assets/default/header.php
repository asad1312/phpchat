<?php
    defined('INSITE') or die('No direct script access allowed');
    if(!$Account->IsLogged()) {
        $Website->Redirect();
    }
?>

<!DOCTYPE html>
<html lang="he" dir="rtl">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="token" content="<?php echo htmlspecialchars($_SESSION['csrf_token']) ?>">
        <title><?php echo $Website->settings->web_title;?></title>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.rtl.min.css" integrity="sha384-gXt9imSW0VcJVHezoNQsP+TNrjYXoGcrqBZJpry9zJt8PCQjobwmhMGaDHTASo9N" crossorigin="anonymous" />
        <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
        <link
            href="https://fonts.googleapis.com/css2?family=Heebo:wght@100;200;300;400;500;600;700;800;900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
            rel="stylesheet"
        />
        <link
            href="https://fonts.googleapis.com/css2?family=Heebo:wght@100;200;300;400;500;600;700;800;900&family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
            rel="stylesheet"
        />
        <link
            href="https://fonts.googleapis.com/css2?family=Heebo:wght@100;200;300;400;500;600;700;800;900&family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
            rel="stylesheet"
        />
        <link rel="stylesheet" href="<?php echo $Website->settings->web_url;?>/assets/<?php echo TEMPLATE_NAME;?>/assets/css/emoji_keyboard.css?v=<?php echo (int)time();?>" />
        <link rel="stylesheet" href="<?php echo $Website->settings->web_url;?>/assets/<?php echo TEMPLATE_NAME;?>/assets/css/jquery.minicolors.css?v=<?php echo (int)time();?>" />
        <link rel="stylesheet" href="<?php echo $Website->settings->web_url;?>/assets/<?php echo TEMPLATE_NAME;?>/assets/css/main.css?v=<?php echo (int)time();?>" />
    </head>
    <body>
        <div id="overlay" class="overlay"></div>
        <header>
            <div class="container xl-container p-0">
                <div class="section-menu">
                    <nav class="navbar navbar-expand-lg navbar-light justify-content-between">
                      <a class="navbar-brand" href="#">
                        <img src="<?php echo $Website->settings->web_url;?>/assets/<?php echo TEMPLATE_NAME;?>/assets/images/logo.svg" alt="" class="img-fluid" />
                      </a>
                      <div>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                          <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <div class="user-options d-flex">
                                <div class="user-count-btn"><a href="#"><i class="fa fa-user"></i><span id="onlineUsers">{{online}}</span></a></div>
                                <form  method="POST" id="update_guest_user_name">
                                    <input type="text" class="mainInput btnshow mx-2" name="username" maxlength="15" placeholder="הכנס,כינוי<?php echo htmlspecialchars($_SESSION['username']);?>" value="<?php echo htmlspecialchars($_SESSION['username']);?>" />
                                    <button class="btn btn-primary change-user-name" type="submit">שינוי משתמש/ התחבר</button>
                                </form>                                
                                <button id="settingsBtn" class="customBtn mx-2" title="הגדרות"><i class="fa fa-cog"></i></button>
                                <button id="logOut" class="customBtn" title="התנתק" onclick="window.location.href = '<?php echo $Website->settings->web_url.'/logout';?>';"><i class="fa fa-sign-out"></i></button>
                            </div>
                        </div>
                      </div>
                    </nav>
                </div>
            </div>
        </header>
        <main class="main-content">
            <div class="container xl-container">
                <div class="row switchButtons mobile-only">
                    <div class="row justify-content-center">
                        <div class="col-md-4 col-4 text-center">
                            <button class="btn btn-primary" type="button" data-widget="rooms">חדרים</button>
                        </div>
                        <div class="col-md-4 col-4 text-center">
                            <button class="btn btn-primary active" type="button" data-widget="chat">צ'אט</button>
                        </div>
                        <div class="col-md-4 col-4 text-center">
                            <button class="btn btn-primary" type="button" data-widget="users">משתמשים</button>
                        </div>
                    </div>
                </div>
                <div class="row text-center siteContent">
                    