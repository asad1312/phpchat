            </div>
        </div>
        <footer>
            <?php echo SMTP_FROM;?>
            <div class="row">
                <div class="col-md-12 col-12">
                    <ul class="p-0 m-0" style="list-style: none;">
                        <li><a href="<?php echo $Website->settings->web_url;?>/terms" target="_blank">תנאי שימוש</a></li>
                        <li><a href="<?php echo $Website->settings->web_url;?>/privacy" target="_blank">מדיניות פרטיות</a></li>
                        <li><a href="mailto:<?php echo CONTACT_EMAIL;?>">צור קשר</a></li>
                    </ul>
                </div>
            </div>
        </footer>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            const App = {
                base_url: '<?php echo $Website->settings->web_url;?>/'
            };
        </script>
        <script src="<?php echo $Website->settings->web_url;?>/assets/<?php echo GUEST_TEMPLATE_NAME;?>/assets/js/global.js?v=<?php echo time();?>"></script>
    </body>
</html>
