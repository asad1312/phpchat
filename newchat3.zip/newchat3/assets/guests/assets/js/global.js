$(document).ready(function () {
    "use strict";
    $.ajaxSetup({
        type: "post",
        url: App.base_url + "ajax_helper.php",
        headers: {
            token: $('meta[name="token"]').attr("content"),
            is_ajax: 1,
        },
        dataType: "json",
        error: function (jqXHR, exception) {
            if (jqXHR.status == 404) {
                alert("Requested page not found. [404]");
            } else if (jqXHR.status == 500) {
                alert("Internal Server Error [500]");
            } else if (jqXHR.status == "429") {
                alert("Refresh page and try again! [429]");
            } else if (exception === "parsererror") {
                alert(jqXHR.responseText);
            } else if (exception === "timeout") {
                alert("Time out error");
            } else if (exception === "abort") {
                alert("Ajax request aborted.");
            }
        },
    });
    function alertShow(title, text, type) {
        if (type == "success") {
            return Swal.fire({
                title: title,
                text: text,
                icon: type,
            }).then(function () {
                location.reload();
            });
        }
        return Swal.fire(title, text, type);
    }
    $(document).on("click", ".switch", function (e) {
        e.preventDefault();
        const title =
            $(this).data("div") == "register_form" ? "הרשמה" : "התחברות";
        $(".left .panel .main-title")
            .fadeOut("fast")
            .html(title)
            .fadeIn("fast");
        $(this)
            .parent()
            .parent()
            .stop(true)
            .animate({ right: 0, width: 0 })
            .fadeOut("fast");
        setTimeout(() => {
            $("#" + $(this).data("div"))
                .animate({ left: 0, width: "100%" })
                .fadeIn("fast");
        }, 250);
    });
    /*$(document).on("click", "#guestLogin", function (e) {
        e.preventDefault();
        var form = $(this);
        var username = $('input[name="username"]');
        var password = $('input[name="password"]');
        $(password).parent().fadeOut();
        if ($(username).val() == "") {
            $(".alert").remove();
            $(
                "<div class='alert alert-info' id='alert'>אנא הכנס שם משתמש!</div>"
            )
                .hide()
                .fadeIn(1500)
                .insertBefore(form);
        }
        $.ajax({
            data:
                $.param({ action: "account", sub_action: "login_guest" }) +
                "&" +
                $(form).serialize(),
            beforeSend: function () {
                $(".alert").remove();
                $("<div class='alert alert-info' id='alert'>אנא המתן...</div>")
                    .hide()
                    .fadeIn(1500)
                    .insertBefore(form);
            },
            success: function (data) {
                if (data.error) {
                    $(".alert").remove();
                    alertShow("שגיאה!", data.error, "error");
                } else {
                    $(".alert").remove();
                    alertShow("מדהים!", data.success, "success");
                }
            },
        });
    });*/
    $(document).on("submit", "#login_form", function (e) {
        e.preventDefault();
        var form = $(this);
        $.ajax({
            data:
                $.param({ action: "account", sub_action: "login" }) +
                "&" +
                $(form).serialize(),
            beforeSend: function () {
                $(".alert").remove();
                $("<div class='alert alert-info' id='alert'>אנא המתן...</div>")
                    .hide()
                    .fadeIn(1500)
                    .insertBefore(form);
            },
            success: function (data) {
                if (data.error) {
                    $(".alert").remove();
                    alertShow("שגיאה!", data.error, "error");
                } else {
                    $(".alert").remove();
                    alertShow("מדהים!", data.success, "success");
                }
            },
        });
    });
    $(document).on("submit", "#register_form", function (e) {
        e.preventDefault();
        var form = $(this);
        $.ajax({
            data:
                $.param({ action: "create_account" }) +
                "&" +
                $(form).serialize(),
            beforeSend: function () {
                $(".alert").remove();
                $("<div class='alert alert-info' id='alert'>אנא המתן...</div>")
                    .hide()
                    .fadeIn(1500)
                    .insertBefore(form);
            },
            success: function (data) {
                if (data.error) {
                    $(".alert").remove();
                    alertShow("שגיאה!", data.error, "error");
                } else {
                    $(".alert").remove();
                    alertShow("מדהים!", data.success, "success");
                }
            },
        });
    });
    $(document).on("submit", "#guest_form", function (e) {
        e.preventDefault();
        var form = $(this);
        $.ajax({
            data:
                $.param({ action: "guest_create_account" }) +
                "&" +
                $(form).serialize(),
            beforeSend: function () {
                $(".alert").remove();
                $("<div class='alert alert-info' id='alert'>אנא המתן...</div>")
                    .hide()
                    .fadeIn(1500)
                    .insertBefore(form);
            },
            success: function (data) {
                if (data.error) {
                    $(".alert").remove();
                    alertShow("שגיאה!", data.error, "error");
                } else {
                    $(".alert").remove();
                    alertShow("מדהים!", data.success, "success");
                }
            },
        });
    });

    $(document).on("submit", "#update_guest_form", function (e) {
        e.preventDefault();
        var form = $(this);
        $.ajax({
            data:
                $.param({ action: "guest_create_account" }) +
                "&" +
                $(form).serialize(),
            beforeSend: function () {
                $(".alert").remove();
                $("<div class='alert alert-info' id='alert'>אנא המתן...</div>")
                    .hide()
                    .fadeIn(1500)
                    .insertBefore(form);
            },
            success: function (data) {
                if (data.error) {
                    $(".alert").remove();
                    alertShow("שגיאה!", data.error, "error");
                } else {
                    $(".alert").remove();
                    alertShow("מדהים!", data.success, "success");
                }
            },
        });
    });


 



});
