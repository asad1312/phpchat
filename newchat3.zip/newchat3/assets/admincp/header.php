<?php defined('INSITE') or die('No direct script access allowed'); ?>
<?php
$Account = new Account;
if(!@$Account->IsAdmin()) $Website->Redirect();
?>
<!DOCTYPE html>
<html lang="he" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title><?php echo $Website->settings->web_title;?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="token" content="<?php echo htmlspecialchars($_SESSION['csrf_token']) ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
    <link rel="stylesheet" href="<?php echo $Website->settings->web_url;?>/assets/admincp/css/vendor/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo $Website->settings->web_url;?>/assets/admincp/css/vendor/bootstrap.rtl.only.min.css" />
    <link rel="stylesheet" href="<?php echo $Website->settings->web_url;?>/assets/admincp/css/dore.light.bluenavy.min.css" />
    <link rel="stylesheet" href="<?php echo $Website->settings->web_url;?>/assets/admincp/css/fontawesome-iconpicker.css" />
    <link rel="stylesheet" href="<?php echo $Website->settings->web_url;?>/assets/admincp/css/main.css" />
    <link rel="stylesheet" href="<?php echo $Website->settings->web_url;?>/assets/admincp/css/dcohen.css" />
</head>

<body id="app-container" class="menu-default show-spinner rtl">
    <div id="notify"></div>
    <nav class="navbar fixed-top">
        <div class="d-flex align-items-center navbar-left">
            <a href="#" class="menu-button d-none d-md-block">
                <svg class="main" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 9 17">
                    <rect x="0.48" y="0.5" width="7" height="1" />
                    <rect x="0.48" y="7.5" width="7" height="1" />
                    <rect x="0.48" y="15.5" width="7" height="1" />
                </svg>
                <svg class="sub" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 17">
                    <rect x="1.56" y="0.5" width="16" height="1" />
                    <rect x="1.56" y="7.5" width="16" height="1" />
                    <rect x="1.56" y="15.5" width="16" height="1" />
                </svg>
            </a>

            <a href="#" class="menu-button-mobile d-xs-block d-sm-block d-md-none">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26 17">
                    <rect x="0.5" y="0.5" width="25" height="1" />
                    <rect x="0.5" y="7.5" width="25" height="1" />
                    <rect x="0.5" y="15.5" width="25" height="1" />
                </svg>
            </a>
        </div>


        <a class="navbar-logo" href="<?php echo $Website->settings->web_url;?>/admin/dashboard">
            <span class="logo d-none d-xs-block"></span>
            <span class="logo-mobile d-block d-xs-none"></span>
        </a>

        <div class="navbar-right">

            <div class="user d-inline-block">
                <button class="btn btn-empty p-0" type="button" data-toggle="222" aria-haspopup="true"
                    aria-expanded="false"> <!-- toggle dropdown disabled !-->
                    <span class="name"><?php echo ucfirst($_SESSION['username']);?></span>
                    <span>
                        <img alt="Profile Picture" src="<?php echo $Website->settings->web_url;?>/assets/admincp/img/profiles/l-1.jpg" />
                    </span>
                </button>

                <div class="dropdown-menu dropdown-menu-right mt-3">
                    <a class="dropdown-item" href="#">Account</a>
                    <a class="dropdown-item" href="#">Features</a>
                    <a class="dropdown-item" href="#">History</a>
                    <a class="dropdown-item" href="#">Support</a>
                    <a class="dropdown-item" href="#">Sign out</a>
                </div>
            </div>
        </div>
    </nav>
    <div class="menu">
        <div class="main-menu">
            <div class="scroll">
                <ul class="list-unstyled">
                    <li class="<?php echo ($page == 'dashboard' ? 'active' : '');?>">
                        <a href="<?php echo $Website->settings->web_url;?>/admin/dashboard">
                            <i class="fa fa-home"></i>
                            <span>דף בית</span>
                        </a>
                    </li>
                    <li class="<?php echo ($page == 'users' ? 'active' : '');?>">
                        <a href="<?php echo $Website->settings->web_url;?>/admin/users">
                            <i class="fa fa-user"></i>
                            <span>משתמשים</span>
                        </a>
                    </li>
                    <li class="<?php echo ($page == 'rooms' ? 'active' : '');?>">
                        <a href="<?php echo $Website->settings->web_url;?>/admin/rooms">
                            <i class="fa fa-tv"></i>
                            <span>חדרים</span>
                        </a>
                    </li>
                    <li class="<?php echo ($page == 'settings' ? 'active' : '');?>">
                        <a href="<?php echo $Website->settings->web_url;?>/admin/settings">
                            <i class="fa fa-gear"></i>
                            <span>הגדרות אתר</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <main>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <h1><?php echo $page;?></h1>
                    <div class="separator mb-5"></div>
                </div>