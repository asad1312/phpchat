<?php 
    defined('INSITE') or die('No direct script access allowed'); 
?>

            </div>
        </div>
    </main>

    <footer class="page-footer">
        <div class="footer-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-sm-6">
                        <p class="mb-0 text-muted">כל הזכויות שמורות <?php echo SMTP_FROM;?> <?php echo date("Y");?></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="<?php echo $Website->settings->web_url;?>/assets/admincp/js/vendor/jquery-3.3.1.min.js"></script>
    <script src="<?php echo $Website->settings->web_url;?>/assets/admincp/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $Website->settings->web_url;?>/assets/admincp/js/fontawesome-iconpicker.js"></script>
    <script src="<?php echo $Website->settings->web_url;?>/assets/admincp/js/dore.script.js"></script>
    <script src="<?php echo $Website->settings->web_url;?>/assets/admincp/js/scripts.js"></script>
    <script>
        const App = {
            base_url: '<?php echo $Website->settings->web_url;?>/'
        };
    </script>
    <script src="<?php echo $Website->settings->web_url;?>/assets/admincp/js/admincp.js?v=<?php echo time();?>"></script>
</body>

</html>