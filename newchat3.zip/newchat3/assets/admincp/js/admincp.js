jQuery(document).ready(function ($) {
    $.ajaxSetup({
        type: "post",
        url: App.base_url + "ajax_helper.php",
        headers: {
            token: $('meta[name="token"]').attr("content"),
            is_ajax: 1,
        },
        dataType: "json",
        error: function (jqXHR, exception) {
            if (jqXHR.status == 404) {
                alert("Requested page not found. [404]");
            } else if (jqXHR.status == 500) {
                alert("Internal Server Error [500]");
            } else if (jqXHR.status == "429") {
                alert("Refresh page and try again! [429]");
            } else if (exception === "parsererror") {
                alert(jqXHR.responseText);
            } else if (exception === "timeout") {
                alert("Time out error");
            } else if (exception === "abort") {
                alert("Ajax request aborted.");
            }
        },
    });
    function runSelector() {
        $(".selector").iconpicker({
            title: "בחר אייקון לתצוגה",
            animation: true,
            hideOnSelect: true,
            inputSearch: true,
            selected: true,
            placement: "center",
        });
    }
    function notify(type, text) {
        $("#notify").removeClass("info");
        $("#notify").removeClass("warn");
        if (type == "error") {
            $("#notify").addClass("warn");
        } else if (type == "info") {
            $("#notify").addClass("info");
        }
        $("#notify").text(text).fadeIn();
        setTimeout(() => {
            $("#notify").fadeOut();
        }, 3000);
    }
    $(document).on("submit", "#createRoom", function (e) {
        e.preventDefault();
        var form = $(this);
        $.ajax({
            data:
                $.param({ action: "admin", sub_action: "create_room" }) +
                "&" +
                $(form).serialize(),
            beforeSend: function () {
                $(".alert").remove();
                $("<div class='alert alert-info' id='alert'>אנא המתן...</div>")
                    .hide()
                    .fadeIn(1500)
                    .insertBefore(form);
            },
            success: function (data) {
                if (data.error) {
                    notify("error", data.error);
                } else {
                    notify("success", data.success);
                    setTimeout(() => {
                        window.location.reload();
                    }, 2000);
                }
            },
        });
    });
    $(document).on("click", "#deleteRoom", function (e) {
        e.preventDefault();
        const room_id = $(this).data("room");
        var parent = $(this);
        if (!confirm("האם אתה בטוח שברצונך למחוק חדר זה?"))
            return notify("error", "אממ...נראה שפעולה זו לא אושרה!");
        $.ajax({
            data: $.param({
                action: "admin",
                sub_action: "delete_room",
                room: room_id,
            }),
            beforeSend: function () {
                $(parent).attr("disabled", true);
                notify("info", "אנא המתן!");
            },
            success: function (data) {
                if (data.error) {
                    notify("error", data.error);
                } else {
                    notify("success", data.success);
                    setTimeout(() => {
                        window.location.reload();
                    }, 2000);
                }
            },
        });
    });
    App.total_rows = $("#total_rows").length ? $("#total_rows").text() : 1;
    runSelector();
    $(".selector").on("iconpickerSelected", function (event) {
        event.preventDefault();
    });
    $(document).on("click", "a", function (e) {
        if ($(this).attr("href") == "#") {
            e.preventDefault();
        }
    });
});
