<?php
    ini_set('display_errors',false);
    ini_set('error_reporting', E_ALL );
    date_default_timezone_set("Asia/Jerusalem");
    ini_set('session.gc_maxlifetime', 86400);
    session_set_cookie_params(86400);
	require 'config.php';
	switch(SHOW_ERRORS){
		case 0:
			ini_set('display_errors', 0);
			ini_set('display_startup_errors', 0);
			error_reporting(0);
			break;
		case 1:
			ini_set('display_errors', 1);
			error_reporting(E_ALL);
			break;
	}
	
	require 'application/functions.php';
	spl_autoload_register(function($class){
			$path = 'application/classes/';
			if(strstr($class, 'HTMLPurifier')){
				$path .= 'htmlpurifier/';
				$class = 'HTMLPurifier.standalone';
			}
			if(in_array($class, ['PHPMailer', 'SMTP'])){
				$path .= 'PHPMailer/class.';
			}
			$path .= $class.'.php';
		require $path;	
	});

	$Security = new Security;