<?php
	session_start();
	require 'autoloader.php';
	$Website = new Website;
	$Account = new Account;
	$data = [];
	if($_SERVER['REQUEST_METHOD'] == 'POST' && $Website->VerifyAjax()) {
		$action = isset($_POST['action']) ? $_POST['action'] : '';
		$sub_action = isset($_POST['sub_action']) ? $_POST['sub_action'] : '';
		switch($action){
			case 'chat':
				switch($sub_action) {
					case 'get_rooms':
						if(!$Account->IsLogged()) {
							$data['error'] = 'אנא התחבר!';
						} else {
							$data['rooms'] = (new Chat)->getChannels();
						}
						break;
					case 'load_chat':
						if(!$Account->IsLogged()) {
							$data['error'] = 'אנא התחבר!';
						} else {
							$post_fields = [
								'channel_id' => isset($_POST['channel_id']) ? (int)$_POST['channel_id'] : ''
							];
							$data = (new Chat)->LoadChat($post_fields);
						}
						break;
					case 'load_users':
						if(!$Account->IsLogged()) {
							$data['error'] = 'אנא התחבר!';
						} else {
							$post_fields = [
								'channel_id' => isset($_POST['channel_id']) ? (int)$_POST['channel_id'] : ''
							];
							$data = (new Chat)->LoadUsers($post_fields);
						}
						break;
					case 'online_users':
						if(!$Account->IsLogged()) {
							$data['error'] = 'אנא התחבר!';
						} else {
							$data['online'] = (new Chat)->OnlineUsers();
						}
						break;
					case 'send_message':
						if(!$Account->IsLogged()) {
							$data['error'] = 'אנא התחבר!';
						} else {
							$post_fields = [
								//'channel_id' => isset($_POST['channel']) ? (int)$_POST['channel'] : '',
								'channel_id' => $_SESSION['room'],
								'color' => isset($_POST['color']) ? trim(str_replace("#", "", $_POST['color'])) : 'ddf',
								'message' => isset($_POST['message']) ? trim($_POST['message']) : ''
							];
							$data = (new Chat)->InsertMessage($post_fields);
						}
						break;
					default:
						$data['error'] = 'בקשה לא תקינה! (5)';
				}
				break;
			case 'admin':
				switch($sub_action) {
					case 'create_room':
						if(!$Account->IsAdmin()) {
							$data['error'] = 'אממ...מה ניסית לעשות? פעולה זו נשלחה למנהל האתר!';
						} else {
							$post_fields = [
								'title' => isset($_POST['title']) ? trim($_POST['title']) : '',
								'icon' => isset($_POST['icon']) ? trim($_POST['icon']) : ''
							];
							$data = (new Admin)->CreateRoom($post_fields);
						}
						break;
					case 'delete_room':
						if(!$Account->IsAdmin()) {
							$data['error'] = 'אממ...מה ניסית לעשות? פעולה זו נשלחה למנהל האתר!';
						} else {
							$post_fields = [
								'room' => isset($_POST['room']) ? (int)$_POST['room'] : '',
							];
							$data = (new Admin)->DeleteRoom($post_fields);
						}
						break;
					default:
						$data['error'] = 'בקשה לא תקינה! (4)';
				}
				break;
			case 'account':
				switch($sub_action) {
					case 'login':
						if($Account->IsLogged()) {
							$data['error'] = 'אנא התנתק לפני ביצוע פעולה זו!';
						} else {
							$post_fields = [
								'username' => isset($_POST['username']) ? trim($_POST['username']) : '',
								'password' => isset($_POST['password']) ? trim($_POST['password']) : '',
							];
							$data = $Account->Login($post_fields);
						}
						break;
					case 'update_mail':
						if(!$Account->IsLogged()) {
							$data['error'] = 'אנא התחבר!';
						} else {
							$post_fields = [
								'currentEmail' => isset($_POST['currentEmail']) ? trim($_POST['currentEmail']) : '',
								'newEmail' => isset($_POST['newEmail']) ? trim($_POST['newEmail']) : '',
							];
							$data = $Account->ChangeEmail($post_fields);
						}
						break;
					case 'update_area':
						if(!$Account->IsLogged()) {
							$data['error'] = 'אנא התחבר!';
						} else {
							$post_fields = [
								'area' => isset($_POST['area']) ? (int)$_POST['area'] : '',
							];
							$data = $Account->ChangeArea($post_fields);
						}
						break;
					case 'update_age':
						if(!$Account->IsLogged()) {
							$data['error'] = 'אנא התחבר!';
						} else {
							$post_fields = [
								'age' => isset($_POST['age']) ? (int)$_POST['age'] : '',
							];
							$data = $Account->ChangeAge($post_fields);
						}
						break;
					case 'update_gender':
						if(!$Account->IsLogged()) {
							$data['error'] = 'אנא התחבר!';
						} else {
							$post_fields = [
								'gender' => isset($_POST['gender']) ? (int)$_POST['gender'] : '',
							];
							$data = $Account->ChangeGender($post_fields);
						}
						break;
					case 'update_about':
						if(!$Account->IsLogged()) {
							$data['error'] = 'אנא התחבר!';
						} else {
							$post_fields = [
								'aboutMe' => isset($_POST['aboutMe']) ? strip_tags(trim($_POST['aboutMe'])) : ''
							];
							$data = $Account->ChangeAbout($post_fields);
						}
						break;
					case 'update_password':
						if(!$Account->IsLogged()) {
							$data['error'] = 'אנא התחבר!';
						} else {
							$post_fields = [
								'currentPassword' => isset($_POST['currentPassword']) ? trim($_POST['currentPassword']) : '',
								'newPassword' => isset($_POST['newPassword']) ? trim($_POST['newPassword']) : '',
								'confirmPassword' => isset($_POST['confirmPassword']) ? trim($_POST['confirmPassword']) : '',
							];
							$data = $Account->ChangePassword($post_fields);
						}
						break;
					case 'get_account_info':
						if(!$Account->IsLogged()) {
							$data['error'] = 'אנא התחבר!';
						} else {
							$post_fields = [
								'user_id' => isset($_POST['user_id']) ? trim($_POST['user_id']) : ''
							];
							$data = $Account->GetProfile($post_fields);
						}
						break;
					default:
					$data['error'] = 'בקשה לא תקינה';
				}
				break;
			case 'create_account':
				if($Account->IsLogged()) {
					$data['error'] = 'אנא התנתק לפני ביצוע פעולה זו!';
				} else {
					$post_fields = [
						'username' => isset($_POST['username']) ? trim($_POST['username']) : '',
						'email' => isset($_POST['email']) ? trim($_POST['email']) : '',
						'password' => isset($_POST['password']) ? trim($_POST['password']) : '',
						'confirm_password' => isset($_POST['confirmPassword']) ? trim($_POST['confirmPassword']) : '',
						'age' => isset($_POST['age']) ? (int)$_POST['age'] : '',
						'gender' => isset($_POST['gender']) ? (int)$_POST['gender'] : '',
						'area' => isset($_POST['area']) ? (int)$_POST['area'] : '',
						'rules' => isset($_POST['rules']) ? 'yes' : 'no',
						'website_url' => $Website->settings->web_url
					];
					$data = $Account->Register($post_fields);
				}
				break;
			case 'guest_create_account':
				if($Account->IsLogged()) {
					$data['error'] = 'אנא התנתק לפני ביצוע פעולה זו!';
				} else {
					$post_fields = [
						'username' => isset($_POST['username']) ? trim($_POST['username']) : '',
						'age' => isset($_POST['age']) ? (int)$_POST['age'] : '',
						'gender' => isset($_POST['gender']) ? (int)$_POST['gender'] : '',
						'area' => isset($_POST['area']) ? (int)$_POST['area'] : '',
						'rules' => isset($_POST['rules']) ? 'yes' : 'no',
						'website_url' => $Website->settings->web_url
					];
					$data = $Account->RegisterGuest($post_fields);
				}
				break;
		
			    
			  
			 case 'update_guest_user_name':
					$post_fields = [
						'username' => isset($_POST['username']) ? trim($_POST['username']) : '',
						'user_id' => $_SESSION['user_id'] ?? '',
					];
					$data = $Account->updateGuestUserName($post_fields);
				break;
			default:
			$data['error'] = 'בקשה לא תקינה';
		}
	}
	else{
		$data['error'] = 'בקשה לא תקינה (6)';
		$data['type'] = 1;
	}
	echo json_encode($data);
